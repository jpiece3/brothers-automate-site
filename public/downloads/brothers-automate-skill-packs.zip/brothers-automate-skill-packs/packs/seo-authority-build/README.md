# Pack: SEO Authority Build

**Mission:** Rank for defensible keywords in 2026 SERPs (post AI Overviews) — keyword selection, content production, and ongoing publishing pipeline.

**Theme:** Content Engine

## Outcome

You walk away with:
- A prioritized keyword cluster scored for AI Overview defensibility (not just volume)
- A pillar SEO post for the top keyword, plus 3-5 supporting posts
- An ongoing publishing pipeline (autopilot) for the rest of the cluster
- Cross-platform atomization of each post

## When to Use This Pack

- You're building organic traffic as a long-term moat (not chasing quick wins)
- You're worried about AI Overviews eating your traffic and want defensible keyword selection
- You have content already but it's not ranking — diagnostic + rebuild

## Prerequisites

- DataForSEO API access (this Pack is data-driven, not vibes-based)
- A domain to publish on
- Patience — SEO is months, not weeks

## The Chain

### Step 1 — `keyword-research-deep`
Deep keyword research with intent classification, SERP feature analysis, and AI Overview defensibility scoring (AODS). Prioritizes keywords by business impact, not raw volume.
- **Output:** Prioritized keyword clusters with defensibility scores
- **Pass to next:** Top cluster + top 5 keywords (compress; don't pass full spreadsheet)

### Step 2 — `seo-blog-writer`
Write a single SEO blog post structured to rank in 2026 SERPs (featured snippets, AI Overview survival).
- **Output:** Pillar post for the top keyword
- **Pass to next:** The post + the supporting keywords

### Step 3 — `seo-content`
Produce 3-5 supporting posts in the cluster that link back to the pillar.
- **Output:** Cluster of supporting content
- **Pass to next:** Each post for polish

### Step 4 — `humanizer`
Strip AI tells. Google's helpful-content updates penalize AI-tell content.
- **Output:** Natural-sounding posts
- **Pass to next:** Cleaned posts

### Step 5 — `content-atomizer`
Repurpose each post into LinkedIn write-up, Twitter thread, newsletter sections.
- **Output:** Cross-platform variants

### Step 6 — `seo-blog-autopilot`
Set up the ongoing pipeline so the rest of the keyword cluster gets published on cadence.
- **Output:** Autopilot configured for the cluster

## Sample Brief

> "I run a fractional CFO consultancy for SaaS. Want to rank for keywords around 'SaaS financial modeling' and 'CFO services for SaaS.' Need defensible picks (AI Overviews are eating finance content). Build me a cluster strategy and the first 3 posts."

## Timeline

- Week 1: Keyword research + cluster picks (step 1)
- Weeks 2-4: Pillar + 3-5 supporting posts (steps 2-4)
- Week 5: Atomize first batch (step 5)
- Ongoing: Autopilot (step 6)

## Anti-Patterns

- ❌ Skipping `keyword-research-deep` for `keyword-research`. The deep version filters for AODS — the regular version gives you keywords that AI Overviews will swallow.
- ❌ Writing the pillar before the supporting posts are mapped out. Internal linking strategy needs to be planned upfront.
- ❌ Atomizing before the post has indexed. Wait 2-3 weeks for indexing + ranking signal before atomizing.

## Not in This Pack

- **Local SEO** — see [Local Lead](../local-lead/README.md)
- **YouTube SEO** — see [YouTube Channel](../youtube-channel/README.md)
- **Backlink building** — out of scope; use a separate outreach process
- **Technical SEO audit** — use `dataforseo` directly for OnPage audits
