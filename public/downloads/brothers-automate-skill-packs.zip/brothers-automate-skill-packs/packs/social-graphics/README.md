# Pack: Social Graphics

**Mission:** Scroll-stopping LinkedIn / Twitter / IG graphics on demand — concepts scored, picked, generated, ready to post.

**Theme:** Visual Production

## Outcome

You walk away with:
- 3 distinct visual directions per concept (different frameworks, not stylistic variations)
- A feed-stop score for each direction
- A drop-in image-gen prompt for the picked direction
- Final, post-ready graphic

## When to Use This Pack

- You need a LinkedIn carousel cover, Twitter image-tweet, quote card, before/after data card, or framework diagram
- A post needs a graphic and a generic stock image won't cut it
- You're A/B testing visuals and want concept variety, not just color swaps

## Prerequisites

- A topic / message the graphic needs to convey
- Platform clarity (LinkedIn vs Twitter vs IG — each has different optimal formats)
- Replicate API access for the image generation

## The Chain

### Step 1 — `scroll-stopping-infographic`
Generates 3 distinct visual directions across 3 different frameworks + one drop-in image-gen prompt per direction.
- **Output:** 3 concept directions with prompts
- **Pass to next:** All 3 to feed-stop scoring

### Step 2 — `feed-stop-score`
Scores each direction on 6 research-backed factors that predict feed engagement on LinkedIn and Twitter (0-100 per direction). Tells you which to pick.
- **Output:** Scored directions + revision recommendations
- **Pass to next:** The winning direction

### Step 3 — `ai-social-graphics`
Specialized social graphics — Instagram posts, YouTube thumbnails, LinkedIn graphics, Twitter images, ad creatives. Apply the picked direction.
- **Output:** Platform-formatted graphic
- **Pass to next:** Final image-gen if needed

### Step 4 — `ai-image-generation`
Replicate-powered image generation if the social graphic needs imagery beyond what `ai-social-graphics` produces natively (e.g., custom illustrations, photographic backgrounds).
- **Output:** Final graphic ready to post

## Sample Brief

> "Need a LinkedIn carousel cover for a post titled 'The 6 reasons most B2B SaaS marketing fails.' Want 3 concept directions, scored, then production-ready."

## Timeline

- Same-session for one graphic
- Batch by topic for series

## Anti-Patterns

- ❌ Skipping `feed-stop-score`. You'll pick the most aesthetic direction, not the most engaging one.
- ❌ Skipping `scroll-stopping-infographic` and going straight to `ai-social-graphics`. You miss the framework-driven concept variety.
- ❌ One direction only. Always evaluate 3 — comparing surfaces what you'd otherwise miss.

## Not in This Pack

- **Product photography** — see [Product Photography](../product-photography/README.md)
- **Presenter video** — see [Presenter / UGC Video](../presenter-ugc-video/README.md)
- **Diagrams (architecture, flow)** — see [Diagrams](../diagrams/README.md)
