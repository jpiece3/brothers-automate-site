# Pack: Brand Reputation

**Mission:** Monitor reviews, mentions, and influencer chatter for a brand — and identify partnership opportunities while you're at it.

**Theme:** Research & Intel

## Outcome

You walk away with:
- Reviews + ratings + sentiment across Google Maps, Booking, TripAdvisor, FB, IG, YouTube, TikTok
- A list of influencers in the brand's adjacent space (with authenticity verification)
- Audience demographic profile (who's actually talking about the brand)

## When to Use This Pack

- You're managing a brand's reputation (yours or a client's) and need a baseline
- You're considering influencer partnerships and need a vetted shortlist
- A negative review storm is brewing and you need to triage scope

## Prerequisites

- Brand name (and any product names)
- Geographic scope (if local-business reputation matters)
- Apify account

## The Chain

### Step 1 — `apify-brand-reputation-monitoring`
Track reviews, ratings, sentiment, brand mentions across all major platforms.
- **Output:** Reputation snapshot — sentiment trends, top issues, top fans
- **Pass to next:** Topics / hashtags / categories surfaced

### Step 2 — `apify-influencer-discovery`
Find and evaluate influencers for partnerships, verify authenticity, track collaboration performance.
- **Output:** Vetted influencer list
- **Pass to next:** Influencer audience segments

### Step 3 — `apify-audience-analysis`
Understand demographics + behavior of the audience talking about the brand (and the audience of the shortlisted influencers).
- **Output:** Audience profile + influencer audience match

## Sample Brief

> "Client is a mid-tier hotel in Lisbon. Want a full reputation scan — reviews across Booking/TripAdvisor/Google, social mentions, and a shortlist of travel influencers we could partner with."

## Timeline

- Week 1: Reputation baseline + influencer scan
- Week 2: Audience match + recommendation

## Anti-Patterns

- ❌ Reacting to a single bad review. Pack delivers patterns — react to patterns, not single data points.
- ❌ Running influencer discovery without authenticity verification. Bot-followed accounts waste budget.
- ❌ Skipping audience analysis. Influencer follower count is meaningless without demographic match.

## Not in This Pack

- **Crisis communications response** — outside scope; this Pack identifies, you respond
- **Active review acquisition** — see [Local Lead](../local-lead/README.md) for `local-seo` review velocity
- **Decomposing a competitor's reputation** — see [Competitor Intelligence](../competitor-intelligence/README.md)
