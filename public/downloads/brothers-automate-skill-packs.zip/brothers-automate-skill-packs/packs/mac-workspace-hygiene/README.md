# Pack: Mac/Workspace Hygiene

**Mission:** Reclaim disk, clean projects, reset the workspace — without manually hunting through Finder.

**Theme:** Operator Stack

## Outcome

You walk away with:
- A cleaned Mac (disk space freed, leftover app files purged)
- A clean project initialization (CLAUDE.md generated for new repos)
- A workspace that doesn't drag

## When to Use This Pack

- "My Mac is full" / "where did my disk space go"
- Starting a new project and want CLAUDE.md scaffolded properly
- Periodic hygiene (monthly / quarterly)

## Prerequisites

- Mole CLI (`mo`) installed via `npm i -g @tw93/mole` for `clean-mac`
- For `init`: a project to initialize

## The Chain

### Step 1 — `clean-mac`
Deep clean using Mole. Frees disk, uninstalls apps with leftovers, analyzes disk usage, clears project build artifacts (node_modules everywhere), shows system health.
- **Output:** Cleaner system + disk usage report
- **Pass to next:** When starting a new project

### Step 2 — `init`
Initialize a new CLAUDE.md file with codebase documentation. Use after `clean-mac` if you're standing up a fresh project.
- **Output:** CLAUDE.md scaffolded for the project

## Sample Brief

> "Mac is at 50GB free out of 1TB. Want a deep clean — nuke node_modules across all my repos, uninstall leftover apps from a few months ago, see what else is eating disk."

## Timeline

- 30-60 minutes for a deep clean
- 5 minutes for a project init

## Anti-Patterns

- ❌ Running `clean-mac` weekly. Once a month or when disk is genuinely full. Over-cleaning wastes time.
- ❌ Initializing CLAUDE.md without then editing it. The init is a starting point — it needs project-specific tuning to be useful.

## Not in This Pack

- **Settings / hooks configuration** — use `update-config` directly
- **Permission prompt cleanup** — use `fewer-permission-prompts` directly
- **Telegram channel setup** — use `telegram:configure` directly
