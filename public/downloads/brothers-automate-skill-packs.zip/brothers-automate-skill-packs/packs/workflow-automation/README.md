# Pack: Workflow Automation

**Mission:** Map an existing Gumloop workflow OR design a new one from requirements.

**Theme:** Build & Ship

## Outcome

You walk away with:
- A workflow specification (maintainable, clear, efficient)
- For ANALYZE mode: a full map of an existing workflow (reverse-engineered)
- For BUILD mode: a new workflow design ready to implement in Gumloop

## When to Use This Pack

- You inherited a Gumloop workflow and need to understand it before modifying
- You have a process to automate and want it specced before building
- You're consolidating multiple ad-hoc workflows into one cleaner design

## Prerequisites

- Gumloop account (for execution; spec can be built without)
- For ANALYZE mode: access to the workflow you want to map
- For BUILD mode: clear requirements for what should happen

## The Chain

### Step 1 — `gumloop-workflow-designer`
Two modes, both produce detailed specifications:
- **ANALYZE:** Reverse-engineer existing workflows. Produces a map.
- **BUILD:** Design from requirements. Produces an implementation-ready spec.

- **Output:** Spec document focused on maintainability + clarity + efficiency

## Sample Brief

> "Want to design a workflow that takes new Stripe payments → enriches the customer → tags in HubSpot → triggers a welcome sequence in Beehiiv. BUILD mode."

## Timeline

- Same-session for the spec
- Implementation in Gumloop: separate

## Anti-Patterns

- ❌ Building in Gumloop without a spec first. Workflows accumulate complexity that becomes unmaintainable.
- ❌ Using ANALYZE mode without giving the skill enough access to the existing workflow. Garbage in.

## Not in This Pack

- **Implementing the workflow in Gumloop** — outside scope; the Pack delivers the spec
- **Workflows in other tools (Zapier, Make, n8n)** — different tool, different patterns
