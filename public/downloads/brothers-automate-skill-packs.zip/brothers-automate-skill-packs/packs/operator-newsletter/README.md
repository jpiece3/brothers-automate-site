# Pack: Operator Newsletter (JFlo)

**Mission:** Run the Operator's AI Playbook newsletter pipeline end-to-end — research, draft, publish, atomize, measure — without manual stitching.

**Theme:** Content Engine

## Outcome

You walk away with:
- A formatted Beehiiv-ready edition in JFlo's operator voice
- Carousel + reel scripts atomized for Instagram
- The full pipeline running on a schedule (research → draft → social → analytics)

## When to Use This Pack

- You're publishing The Operator's AI Playbook and want the automated pipeline (not the manual newsletter chain)
- You have raw notes (automation topic, pain point, steps, ROI) and need them formatted
- You want the Instagram atomization step running automatically post-publish

## Prerequisites

- Beehiiv account configured for the newsletter
- Notion / source material for raw playbook notes
- The 5 specialized agents that `newsletter-autopilot` orchestrates are wired up
- This is *the* pipeline for The Operator's AI Playbook — for any other newsletter, use [Newsletter Launch](../newsletter-launch/README.md) instead

## The Chain

### Step 1 — `operator-playbook-drafter`
Transform raw notes (automation topic, pain point, steps, ROI) into Beehiiv-ready format in JFlo's voice.
- **Output:** Formatted edition ready for editorial pass
- **Pass to next:** Final approved edition

### Step 2 — `newsletter-autopilot`
Orchestrates 5 agents: research, drafting, publishing, social atomization, analytics.
- **Output:** Published newsletter + scheduled social
- **Pass to next:** Published edition link

### Step 3 — `operator-social-atomizer`
Transform the published edition into Instagram-optimized content: 8-10 slide carousels, 15-30 sec reel scripts, story sequences.
- **Output:** Canva-ready carousel text + video scripts

## Sample Brief

> "Topic: Automating customer support triage with Claude. Pain point: 4 hours/day on first-pass triage. Steps: webhook into Zendesk → Claude classifies → routes to right agent. ROI: 4 hours/day saved, 2× faster first response. Draft this for next week's edition."

## Timeline

- Same-day for the drafter (step 1)
- Autopilot pipeline runs on its own cadence
- Atomizer triggered post-publish

## Anti-Patterns

- ❌ Using this for non-JFlo newsletters. The voice and format are JFlo-specific. Use [Newsletter Launch](../newsletter-launch/README.md) instead.
- ❌ Skipping the human editorial pass between steps 1 and 2. Autopilot publishes — make sure what's drafted is what you want live.

## Not in This Pack

- **Newsletter strategy / format choice** — already locked for The Operator's AI Playbook
- **Voice definition** — JFlo's voice is already encoded in the drafter
