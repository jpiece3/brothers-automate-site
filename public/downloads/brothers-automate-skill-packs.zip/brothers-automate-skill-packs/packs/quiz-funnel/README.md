# Pack: Quiz Funnel

**Mission:** Build a quiz-based lead generation system end-to-end — research, architecture, copy, design, build, and ongoing optimization.

**Theme:** Lead Engine

## Outcome

You walk away with:
- 14 implementation-ready files: research, quiz architecture, copy, landing page, 14 nurture emails, builder prompt
- Database schema and Supabase setup
- Monthly optimization reports once 30+ days of data is collected

## When to Use This Pack

- You want a quiz as your primary lead magnet (not a PDF / checklist)
- You want hot/warm/cold segmentation based on quiz answers, with email sequences matched to result temperature
- You're committing to a lead-gen system, not a one-off campaign

## Prerequisites

- A business URL or context file describing the offer
- Supabase account
- A no-code builder (Replit recommended) or willingness to deploy the generated HTML
- An ESP for the email sequences

## The Chain

### Step 1 — `lead-magnet-quiz`
Fully orchestrated multi-agent workflow. Spawns 4 specialized agents:
- **Research agent** (Tavily, DataForSEO, Playwright): research.md, validates 3 segments + 5+ angles + SEO keywords
- **Architecture + Design agents (parallel)**: quiz structure, scoring model, routing logic, color palette, CSS components
- **Copy agent**: landing page, quiz questions, result pages, 14 emails
- **Build agent**: functional HTML, Replit builder prompt, README

**Output:** 14 files including landing-page.html, builder-prompt.md, email-sequences.md
**Pass to next:** Builder prompt + DB schema

### Step 2 — `setup-quiz-db`
Create the Supabase database for quiz responses, scoring, segmentation.
- **Output:** Live database + connection details
- **Pass to next:** Live quiz URL once deployed

### Step 3 — `funnel-optimizer` (after 30+ days of data)
Monthly optimization report analyzing Supabase analytics, identifying conversion bottlenecks, prioritized recommendations.
- **Output:** Optimization report
- **Loop back:** Apply changes, measure, repeat

## Sample Brief

> "Business URL: example.com. We sell a fractional CFO service to SaaS founders. Want a quiz called 'What's Your CFO Readiness Score?' that scores founders, segments them, and routes hot leads to a discovery call and warm leads to a 14-email nurture sequence."

## Timeline

- Week 1: Run `lead-magnet-quiz` (it's orchestrated, fast)
- Week 2: Database setup + deploy
- Weeks 3-6: Drive traffic, collect data
- Week 7+: First optimization report (after 30 days)

## Anti-Patterns

- ❌ Running this Pack and then not driving traffic to the quiz. The optimization step needs data — without traffic, you've built a beautiful funnel that does nothing.
- ❌ Tweaking the funnel weekly. Wait for the optimizer report (30 days minimum). Premature changes destroy the signal.
- ❌ Using this Pack for a non-quiz lead magnet. Use [Lead Magnet → Welcome](../lead-magnet-welcome/README.md) for PDFs/checklists.

## Not in This Pack

- **Driving traffic** — see [Paid Acquisition](../paid-acquisition/README.md), [SEO Authority Build](../seo-authority-build/README.md), [LinkedIn Authority](../linkedin-authority/README.md)
- **Discovery call booking system** — outside scope; integrate Cal.com / Calendly
- **CRM integration** — outside scope; pipe Supabase to your CRM via webhook
