# Pack: Strategist

**Mission:** Get unstuck. Find the angle. Route to the right Pack. The fractional CMO / strategist layer.

**Theme:** Operator Stack

## Outcome

You walk away with:
- A diagnosed situation (where you are, what's missing)
- A clear next-step recommendation (which Pack to run)
- A bold, decisive direction — not a hedged committee answer

## When to Use This Pack

- You're stuck and don't know what to do next
- A situation feels off and you can't articulate why
- You need a strategy session before committing to execution

## Prerequisites

- Willingness to answer qualifying questions honestly
- A goal (even a vague one)

## The Chain

### Step 1 — `orchestrator`
The marketing strategist. Asks qualifying questions, diagnoses, recommends a Pack or skill sequence.
- **Output:** Recommended Pack with rationale
- **Pass to next:** Use the recommendation, OR continue to step 2 if the situation needs deeper strategy

### Step 2 — `wed` (What Would Elon Do?)
For ambitious / startup ideas — transforms an idea into a ruthless execution plan with MVP spec, GTM plan, first-week actions.
- **Output:** Execution plan
- **Pass to next:** If the idea needs creative angle work, continue

### Step 3 — `ai-creative-strategist`
Strategic creative thinking partner. For campaigns, naming, concepts, angles, visual direction, when you're stuck.
- **Output:** Strategic recommendations + creative concepts
- **Pass to next:** Locked angle for positioning

### Step 4 — `positioning-angles`
Find the differentiated angle. Use when the strategist work surfaces that positioning is the bottleneck.
- **Output:** 3-5 positioning options
- **Pass to next:** When something *still* isn't working

### Step 5 — `diagnose`
When the first fix didn't work. Forces structured re-diagnosis instead of layering more patches.
- **Output:** Root-cause analysis

## Sample Brief

> "I have a course launch in 6 weeks. List is small (2K), no paid budget, and the existing landing page isn't converting. Where do I start?"

## Timeline

- 30-60 minutes for full strategy session
- Then off to the recommended Pack(s)

## Anti-Patterns

- ❌ Skipping `orchestrator` and going straight to execution. Saves 30 minutes upfront, costs days of wrong-direction work.
- ❌ Running `wed` for non-startup contexts. It's tuned for ambitious / 0→1 / "think bigger" — won't help with optimizing an existing system.
- ❌ Ignoring `diagnose` after a failed first fix. The instinct to layer patches is wrong — re-diagnose.

## Not in This Pack

- **Execution itself** — this Pack routes you to other Packs for execution
- **Skill creation** — see [Skill Building](../skill-building/README.md)
