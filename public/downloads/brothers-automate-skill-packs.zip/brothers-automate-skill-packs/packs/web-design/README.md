# Pack: Web Design

**Mission:** Frontend-first design and scoping for a marketing site — clickable mockup before any backend wiring.

**Theme:** Visual Production

## Outcome

You walk away with:
- A clickable mockup of the site / page
- A design direction picked from one of 6 style families (Soft / Sharp / Glass / Glossy / etc.)
- Production-ready UI components in the chosen style
- A complete page or site you can deploy

## When to Use This Pack

- You're designing a new marketing site and want to see it before building
- You're redesigning and need to lock direction before refactoring
- You're scoping a project and need a clickable mockup for sign-off

## Prerequisites

- Page intent / sitemap (one page or multi-page)
- Some idea of the audience (drives style direction)
- A deployment target (Vercel, Webflow, Framer, etc.)

## The Chain

### Step 1 — `mockup`
Frontend-first scoping. Build a clickable UI mockup before any backend or DB work. This step locks the direction with the stakeholder.
- **Output:** Clickable mockup at localhost
- **Pass to next:** Approved mockup + style preferences for direction

### Step 2 — `web-designer`
Pick the design direction (one of 6 style families) and apply the page-type framework.
- **Output:** Design brief + style tokens + section-by-section layout
- **Pass to next:** Direction + tokens for component production

### Step 3 — `ui`
Generate production-ready UI in the chosen style (Soft / Sharp / Glass / Glossy). Specifications for dashboards, landing pages, marketing sites, e-commerce.
- **Output:** Final, deployable UI

## Sample Brief

> "Designing a marketing site for a new fractional CMO consultancy. Audience: B2B SaaS founders. Want a Sharp aesthetic — minimal, opinionated, anti-corporate. Need home, about, services, contact pages."

## Timeline

- Day 1: Mockup (step 1) → approval
- Days 2-3: Direction + UI (steps 2-3)
- Day 4: Deploy

## Anti-Patterns

- ❌ Skipping `mockup` because "I know what I want." Mockups catch misalignments early — cheaper than rebuilding after CSS is written.
- ❌ Picking a style direction without thinking about the audience. Glass aesthetic for a serious B2B finance product = mismatch.
- ❌ Building the backend before the frontend is approved. Frontend-first is a hard rule (per CLAUDE.md).

## Not in This Pack

- **Landing page (single page) for a specific offer** — see [Landing Page Conversion](../landing-page-conversion/README.md) — that one includes the copy step
- **App spec / iOS** — see [App Spec](../app-spec/README.md)
- **Backend / API / DB** — outside scope
