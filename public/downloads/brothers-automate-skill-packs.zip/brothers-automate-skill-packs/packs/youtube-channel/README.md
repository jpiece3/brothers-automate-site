# Pack: YouTube Channel

**Mission:** Launch and package a YouTube channel optimized for CTR in Browse + Suggested — keyword-driven topics, scripts engineered for retention, AI talking head for production.

**Theme:** Content Engine

## Outcome

You walk away with:
- A prioritized YouTube keyword strategy
- Scripts for the first 3-5 videos
- AI-generated talking head footage for each script (or a humans-in-front-of-camera plan)
- Title + thumbnail + description for each video built for CTR

## When to Use This Pack

- You're starting a YouTube channel and don't want to film 10 videos that flop before figuring out packaging
- You have a channel that's getting impressions but no clicks (CTR problem)
- You want to publish without being on camera — AI talking head route

## Prerequisites

- A YouTube channel
- A topic / niche
- Either: a face you'll put on camera, OR an AI-talking-head license / setup

## The Chain

### Step 1 — `keyword-research`
YouTube-specific keyword research (different from blog SEO — different intent, different SERP).
- **Output:** Prioritized topic clusters
- **Pass to next:** Top topic + supporting keywords

### Step 2 — `short-form-video-scripts`
Even for long-form YouTube, the hook architecture from short-form holds — first 15 seconds determine retention. Use this for the script skeleton.
- **Output:** Script with hook → setup → payoff arc
- **Pass to next:** Script for packaging

### Step 3 — `youtube-seo-packaging`
Title + thumbnail brief + description engineered for Browse and Suggested CTR.
- **Output:** Title, thumbnail design brief, optimized description
- **Pass to next:** Script + packaging for production

### Step 4 — `ai-talking-head` (optional)
If you're not filming yourself, generate a UGC-style talking head reading the script.
- **Output:** Talking head footage
- **Pass to next:** Footage + B-roll plan

### Step 5 — `remotion`
For programmatic editing, animations, or scaling up production using React-based video composition.
- **Output:** Edited video ready to upload

## Sample Brief

> "Starting a YouTube channel for indie developers. Topics around shipping side projects, monetization, and AI-assisted coding. Don't want to be on camera — using AI talking head. Build me the first 3 videos."

## Timeline

- Week 1: Keyword strategy + first 3 scripts (steps 1-2)
- Week 2: Packaging for all 3 (step 3)
- Week 3-4: Production (steps 4-5)
- Week 5: Publish, measure CTR, iterate

## Anti-Patterns

- ❌ Treating YouTube like a blog. Search intent is different — people on YouTube want demonstration, not summary.
- ❌ Skipping `youtube-seo-packaging`. A great video with a bad title gets 50 views. Packaging is the deciding factor in Browse / Suggested.
- ❌ Trying to ship weekly with this Pack out of the gate. Build the first 3, watch the data, then commit to cadence.

## Not in This Pack

- **YouTube Shorts strategy** — overlaps but use [Viral Sprint](../viral-sprint/README.md) for short-form-specific principles
- **Channel branding / banner / about page design** — use [Web Design](../web-design/README.md) for the visual system
