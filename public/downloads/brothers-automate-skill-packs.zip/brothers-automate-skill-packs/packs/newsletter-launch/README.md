# Pack: Newsletter Launch

**Mission:** Ship a newsletter readers actually open — voice, format, and first three editions in 1-2 weeks.

**Theme:** Content Engine

## Outcome

You walk away with:
- A defined newsletter voice (consistent across editions)
- A chosen format (roundup / deep-dive / personal essay / curated links / news briefing)
- Issue 1, 2, and 3 ready to publish
- A 14-day social atomization plan repurposing each issue into LinkedIn, Twitter, and IG posts

## When to Use This Pack

- You're starting a newsletter from scratch and don't yet know the voice or format
- You have a newsletter that's getting opened but not read — voice/format diagnostic
- You're about to launch and want a 3-issue runway in the can before going public

## Prerequisites

- A topic / beat you can write 30+ issues about without running out
- An audience hypothesis (who is this for, what do they care about)
- An email service set up (Beehiiv, Substack, ConvertKit) — not in this Pack

## The Chain

### Step 1 — `brand-voice`
Define how the newsletter sounds. Use Extract mode if you have prior writing samples; Build mode if starting from scratch.
- **Output:** Voice profile document
- **Pass to next:** Voice summary (3 sentences max — see Context Paradox)

### Step 2 — `positioning-angles`
Find the differentiated angle for the newsletter. What's the one perspective only you have?
- **Output:** 3-5 positioning options with headline directions
- **Pass to next:** Winning angle (1-2 sentences only)

### Step 3 — `newsletter`
Pick the format that matches the angle and voice. Build the template.
- **Output:** Format choice + template + framework for ongoing editions
- **Pass to next:** Format spec + template

### Step 4 — `email-newsletter-writer`
Draft issues 1, 2, and 3. Each gets a subject line optimized for opens.
- **Output:** 3 publication-ready editions
- **Pass to next:** Each edition individually for the polish pass

### Step 5 — `humanizer`
Strip AI tells from each edition. Em dashes, rule of three, vague attributions, etc.
- **Output:** De-AI'd editions
- **Pass to next:** Cleaned editions to anti-slop

### Step 6 — `anti-slop`
Final originality / sourcing / argument check. Catches what humanizer missed.
- **Output:** Audit-passed editions ready to publish

### Step 7 — `content-atomizer`
Repurpose each edition into platform-native posts (LinkedIn, Twitter, IG carousel).
- **Output:** ~30 social posts (10 per edition × 3 editions)

## Sample Brief

> "I want to launch a weekly newsletter for B2B SaaS founders who are tired of growth-hack content and want operator-led essays on building durable companies. My voice is contrarian, plain-spoken, and skeptical of trends. I have ~5 prior LinkedIn posts I'm proud of as voice samples."

## Timeline

- Week 1: Voice + positioning + format (steps 1-3)
- Week 2: Draft + polish 3 issues (steps 4-6)
- Week 3+: Atomize as you publish (step 7, ongoing)

## Anti-Patterns

- ❌ Skipping `brand-voice` because "I know how I sound." If you can't articulate it in writing, future editions will drift.
- ❌ Skipping `positioning-angles` because "the topic is the angle." A topic is not an angle — Sahil Bloom and Lenny Rachitsky cover overlapping topics with completely different angles.
- ❌ Drafting all 3 editions in the same session. Voice fatigue degrades issue 3. Space them.
- ❌ Skipping `humanizer` and `anti-slop` to save time. AI-tell content kills opens within 2-3 issues.

## Not in This Pack

- **Subject line A/B testing infrastructure** — handle in your ESP
- **Growth / list-building tactics** — see [Lead Magnet → Welcome](../lead-magnet-welcome/README.md)
- **Long-running automation pipeline** — see [Operator Newsletter](../operator-newsletter/README.md)
