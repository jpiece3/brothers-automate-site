# Pack: Local Lead

**Mission:** Rank in the Google local 3-pack AND turn that visibility into outbound campaigns.

**Theme:** Lead Engine

## Outcome

You walk away with:
- An optimized Google Business Profile
- A review velocity plan (how many reviews, on what cadence, from whom)
- A local citation build-out
- A prospect list of complementary local businesses + a cold sequence to reach them

## When to Use This Pack

- You serve a local geography (legal, medical, home services, restaurants, local agencies)
- You're not in the 3-pack and your competitors are
- You want to combine local SEO with outbound (the often-missed combo)

## Prerequisites

- A Google Business Profile (claimed)
- A primary service area
- A reason to be in the 3-pack (you actually serve customers there)

## The Chain

### Step 1 — `local-seo`
Optimize GBP, hit review velocity targets, build local citations to rank in the 3-pack.
- **Output:** Optimized GBP + review acquisition plan + citation list
- **Pass to next:** The geography + service category

### Step 2 — `prospect-finder`
Find complementary local businesses in the same geography (not competitors — adjacent businesses you can refer to / from).
- **Output:** CSV of local businesses
- **Pass to next:** Filtered list + your value prop

### Step 3 — `cold-email-sequence`
Build a localized cold sequence — referencing the geography, the local context, common ground.
- **Output:** Sequence ready for outbound

## Sample Brief

> "I run a residential cleaning service in Lansdale, PA. Want to rank in the local 3-pack for 'house cleaning Lansdale' and reach out to local realtors / property managers for referral partnerships."

## Timeline

- Weeks 1-2: GBP optimization + review push (step 1)
- Week 3: Prospect list + outreach (steps 2-3)
- Months 2-3: Compounding — local SEO ranks improve as reviews and citations accumulate

## Anti-Patterns

- ❌ Optimizing GBP without a review velocity plan. NAP consistency alone won't beat competitors with 100+ reviews.
- ❌ Treating local SEO and outbound as separate workstreams. Combined, they reinforce each other (more visibility = warmer outbound).
- ❌ Outreach to direct competitors. This Pack targets *complementary* businesses for referral relationships, not your own customers.

## Not in This Pack

- **National SEO** — see [SEO Authority Build](../seo-authority-build/README.md)
- **Reputation management for negative reviews** — see [Brand Reputation](../brand-reputation/README.md)
- **Paid local ads** — see [Paid Acquisition](../paid-acquisition/README.md)
