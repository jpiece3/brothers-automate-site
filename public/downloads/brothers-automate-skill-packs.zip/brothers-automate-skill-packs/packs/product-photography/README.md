# Pack: Product Photography

**Mission:** Generate hero / lifestyle / e-comm product shots without a studio, photographer, or shoot day.

**Theme:** Visual Production

## Outcome

You walk away with:
- Production-ready hero images for the product (white-background, lifestyle, in-context)
- A library of variations for testing across landing pages and ads
- Replicable prompt templates for future products in the same line

## When to Use This Pack

- You're launching a product and don't have studio budget / time
- You need lifestyle shots in contexts you can't easily shoot (different cities, climates, demographics)
- You're A/B testing creative for ads and need variations fast

## Prerequisites

- Source images of the actual product (the AI fills in the context, not the product)
- Replicate API access (for `ai-image-generation`)
- A clear visual direction (mood, audience, context)

## The Chain

### Step 1 — `ai-product-photo`
Specialized for product photography — hero images, lifestyle, e-commerce visuals. This is the higher-quality / domain-specific entry point.
- **Output:** Production-ready product shots
- **Pass to next:** Concept variations needed

### Step 2 — `ai-image-generation`
General image generation via Replicate. Use for the variations / lifestyle / context shots that `ai-product-photo` doesn't natively cover.
- **Output:** Image library

## Sample Brief

> "Launching a new line of espresso cups. Need hero shots (white background) plus lifestyle shots in 3 contexts: minimalist Scandi kitchen, sun-drenched Italian café, modern coworking space."

## Timeline

- Day 1: Hero shots (step 1)
- Day 2: Lifestyle variations (step 2)

## Anti-Patterns

- ❌ Using AI imagery without the actual product as a source. The AI invents details — wrong number of cup handles, wrong logo placement, etc.
- ❌ Skipping `ai-product-photo` and going straight to `ai-image-generation` for product shots. The specialized skill has product-specific quality controls.

## Not in This Pack

- **Animated product video** — see [Product Video](../product-video/README.md)
- **Social-formatted graphics with overlay text** — see [Social Graphics](../social-graphics/README.md)
- **Talking-head presenter video for the product** — see [Presenter / UGC Video](../presenter-ugc-video/README.md)
