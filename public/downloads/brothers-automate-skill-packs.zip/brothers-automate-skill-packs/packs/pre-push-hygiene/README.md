# Pack: Pre-Push Hygiene

**Mission:** Don't push broken code. Run typecheck / build / lint, ship clean, never push secrets, never collide with running dev servers.

**Theme:** Build & Ship

## Outcome

You walk away with:
- A green pre-push gate (typecheck + build + lint all pass)
- A clean commit + push without secrets exposure
- A safe local dev environment that doesn't burn CPU or collide on ports
- A simplified codebase (no dead code, no premature abstractions)

## When to Use This Pack

- Before any `git push` — this is the hard rule per CLAUDE.md
- After significant refactors when you want to verify nothing broke
- When local dev has been flaky (port collisions, runaway Turbopack)

## Prerequisites

- A repo with TypeScript (for `tsc --noEmit`), build script, lint command
- Git remote configured

## The Chain

### Step 1 — `precheck`
Run typecheck, build, lint. Stop on first failure. This is the gate.
- **Output:** Pass / fail report with first 20 lines of errors
- **Pass to next:** If green, continue; if red, fix and re-run

### Step 2 — `ship`
Run typecheck + build, then commit + push if both pass. Combines the gate + the action.
- **Output:** Pushed commit
- **Pass to next:** Optionally `push-to-github` for explicit safety check

### Step 3 — `push-to-github`
Safety checks before push: credential exposure, wrong-repo pushes, large file commits, force-push accidents.
- **Output:** Verified push

### Step 4 — `safedev`
Resource-safe dev server. No Turbopack, no surprise launches, no port collisions. Use after pushing to verify the next dev session starts clean.
- **Output:** Running dev server

### Step 5 — `simplify`
Review changed code for reuse, quality, efficiency. Fix any issues found. Use as periodic hygiene, not before every push.
- **Output:** Simplified codebase

## Sample Brief

> "Just finished a feature. Want to run the full pre-push hygiene chain: precheck, ship, verify, then start a clean dev server."

## Timeline

- Same-session (5-15 minutes depending on suite size)

## Anti-Patterns

- ❌ Skipping `precheck` because "the changes are small." Small changes break builds all the time.
- ❌ Using `--no-verify` to skip pre-commit hooks. If a hook fails, fix the underlying issue.
- ❌ Force-pushing to main / master. The Pack will warn you; don't override the warning.

## Not in This Pack

- **PR review** — see [Code Review](../code-review/README.md)
- **Security review specifically** — see [Code Review](../code-review/README.md)
- **CI/CD pipeline configuration** — outside scope
