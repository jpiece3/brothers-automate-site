# Pack: Universal Scrape

**Mission:** Pull data from any web source — social, e-commerce, search, maps — using Apify + Firecrawl.

**Theme:** Research & Intel

## Outcome

You walk away with:
- Structured data (CSV / JSON) from whatever source you needed
- Reusable scraper configurations for repeat runs
- A pattern for pulling data when no dedicated Pack covers your need

## When to Use This Pack

- You need data from a source none of the other Research Packs cover
- You're doing one-off research that doesn't fit a recurring pattern
- You're building a custom dataset (training data, market intel, lead enrichment)

## Prerequisites

- Apify account
- Firecrawl MCP configured (for the non-Apify portions)
- Some idea of the schema you want output in

## The Chain

### Step 1 — `apify-ultimate-scraper`
Universal AI-powered scraper. Handles IG, FB, TikTok, YouTube, Google Maps, Google Search, Google Trends, Booking, TripAdvisor. Most general use cases hit this one.
- **Output:** Structured data per query
- **Use case:** When the source is on the supported platforms list

### Step 2 — `apify-ecommerce`
E-comm-specific scrapers — pricing, reviews, sellers across Amazon, Walmart, eBay, IKEA, 50+ marketplaces.
- **Output:** Product + pricing + review data
- **Use case:** When the source is a marketplace

### Step 3 — Firecrawl MCP (not a skill)
For arbitrary web sources not covered by Apify. Use the Firecrawl MCP tools directly:
- `firecrawl_scrape` — single page
- `firecrawl_crawl` — multi-page site
- `firecrawl_extract` — schema-driven extraction
- `firecrawl_search` — search-then-scrape
- **Use case:** Any web source not on Apify's supported platforms

## Sample Brief

> "Need to pull all current pricing for [product category] across Amazon, Walmart, and 3 niche marketplaces. Want the data refreshed monthly."

## Timeline

- Same-day for one-off pulls
- Set up cron / `loop` for recurring pulls

## Anti-Patterns

- ❌ Defaulting to Firecrawl when an Apify scraper exists. Apify is faster for supported platforms.
- ❌ Not validating the output schema before scaling up the run. Bad schema = wasted credits.
- ❌ Scraping at scale without rate-limiting. Get your IP/account flagged, lose access.

## Not in This Pack

- **Lead generation specifically** — see [Cold Outreach](../cold-outreach/README.md)
- **Competitor intelligence specifically** — see [Competitor Intelligence](../competitor-intelligence/README.md)
- **Brand reputation specifically** — see [Brand Reputation](../brand-reputation/README.md)
- **Building a custom Apify Actor** — see [Apify Actor Build](../apify-actor-build/README.md)
