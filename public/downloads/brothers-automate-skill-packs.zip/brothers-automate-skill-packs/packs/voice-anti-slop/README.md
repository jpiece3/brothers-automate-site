# Pack: Voice & Anti-Slop

**Mission:** Lock down a brand voice, kill AI tells, ship copy that reads like a human wrote it.

**Theme:** Operator Stack

## Outcome

You walk away with:
- A defined voice profile that other skills can pull from
- Audited content with AI tells stripped
- Originality / sourcing / argument check passed
- A diagnostic for any underperforming asset

## When to Use This Pack

- You're starting any content / copy work and the voice isn't defined
- You have content that's ready to ship but reads as AI-generated
- You have content that's underperforming and need a fast diagnostic

## Prerequisites

- For voice extraction: 5-10 content samples you're proud of
- For voice build (no samples): strategic answers about how you want to sound

## The Chain

### Step 1 — `brand-voice`
Define how you sound. Two modes:
- **Extract:** analyze existing content you're proud of
- **Build:** strategically construct from scratch
- **Output:** Voice profile document (used as input to all other content/copy skills)
- **Pass to next:** When you have content drafted, run through humanizer

### Step 2 — `humanizer`
Strip AI tells from text. Based on Wikipedia's "Signs of AI writing" guide. Catches em dashes, rule of three, vague attributions, AI vocabulary, negative parallelisms, conjunctive phrases.
- **Output:** Cleaner text
- **Pass to next:** For long-form, anti-slop catches what humanizer missed

### Step 3 — `anti-slop`
Audit content for AI-slop signals across 5 tiers (text, structure, sourcing, voice, argument). Rewrite to pass.
- **Output:** Audit-passed content
- **Pass to next:** If content is still underperforming, diagnose

### Step 4 — `auto-improve`
Audits existing content, identifies why it's underperforming, routes to the right skill to fix. Use as the diagnostic when something is off and you can't articulate what.
- **Output:** Diagnosis + recommended next skill

## Sample Brief

> "Have 5 LinkedIn posts I'm proud of. Want to extract my voice, then run my latest 3 drafts through humanizer + anti-slop before I post."

## Timeline

- Voice extraction: 1-2 hours
- Per-piece audit: 15-30 minutes

## Anti-Patterns

- ❌ Defining voice once and never updating it. Voice drifts; re-extract every 6 months.
- ❌ Skipping `humanizer` because the writing "feels human." AI tells are subtle — get a second opinion.
- ❌ Running `anti-slop` on every short post. Reserve for long-form where the bar is higher.
- ❌ Using `auto-improve` as the *first* step. Use it diagnostically *after* a piece has flopped, not before publishing.

## Not in This Pack

- **Generating content from scratch** — see Content Engine packs
- **Strategic positioning** — see [Strategist](../strategist/README.md)
