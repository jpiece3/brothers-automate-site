# Pack: Diagrams

**Mission:** Build technical / strategy / architecture diagrams fast.

**Theme:** Visual Production

## Outcome

You walk away with:
- An Excalidraw diagram (sketchy, hand-drawn aesthetic) for whatever you needed to show
- An exportable file (PNG / SVG) for embedding in docs / decks / posts

## When to Use This Pack

- You need to show an architecture, flow, system diagram, or strategy framework
- You want the "hand-drawn whiteboard" aesthetic that's become the standard for technical content
- You're publishing technical content where a clean diagram beats prose

## Prerequisites

- A clear concept of what the diagram should show

## The Chain

### Step 1 — `excalidraw`
Excalidraw Diagram Builder. Single skill, single output.
- **Output:** Diagram

## Sample Brief

> "Build me a diagram showing the data flow for a webhook-driven AI triage system: incoming webhook → classifier → router → 3 agent paths (auto-respond, escalate, queue)."

## Timeline

- Same-session

## Anti-Patterns

- ❌ Using Excalidraw for diagrams that need precision (CAD-level, exact-scale). Use a real diagramming tool for those.
- ❌ Diagramming when prose would do. If the relationship between concepts is linear, a diagram is overkill.

## Not in This Pack

- **Strategy/system diagrams that need a deck or web treatment** — pair this with [Web Design](../web-design/README.md) or [Social Graphics](../social-graphics/README.md)
- **Code visualization** — outside scope
