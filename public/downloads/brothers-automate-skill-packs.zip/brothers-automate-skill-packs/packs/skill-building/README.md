# Pack: Skill Building

**Mission:** Productize a workflow into a research-backed Claude Code skill.

**Theme:** Operator Stack

## Outcome

You walk away with:
- A complete SKILL.md following the 10-element template
- A `references.md` companion with citations
- Optionally `frameworks.md` if the patterns are deep
- A skill that's defensible (citations, data backing, worked examples)

## When to Use This Pack

- You have a workflow you keep repeating manually and want it productized
- You're extending the research-backed skill pack
- You want to sell or distribute a skill (defensibility matters)

## Prerequisites

- A clear job-to-be-done (input → output) for the skill
- Either: source material to operationalize, OR willingness to scrape ≥10 examples for research backing
- Familiarity with the existing skills directory

## The Chain

### Step 1 — `skill-creator`
Build the skill end-to-end. Phased workflow:
1. Scope + naming (collision check, JTBD definition)
2. Research (scrape 10-20 examples) OR use provided source material
3. Framework extraction (≥30% pattern + correlation)
4. Draft SKILL.md (10-element template)
5. Companion files (references.md, frameworks.md)
6. Verification (frontmatter parse, smoke test, citation audit)

- **Output:** Complete skill at `~/.claude/skills/<slug>/`

## Sample Brief

> "Want to productize my client onboarding checklist into a skill called `client-onboarding`. Two modes: NEW CLIENT (kickoff workflow) and HEALTH CHECK (mid-engagement audit). I have my own checklist as source material."

## Timeline

- Same-day for skills built from provided source material
- 2-3 days for skills requiring fresh scraping research

## Anti-Patterns

- ❌ Skipping the research phase. Skills written from memory are indistinguishable from prompts.
- ❌ Citing patterns that appear in <30% of examples. That's noise, not signal.
- ❌ Worked examples that don't show the framework in action. Must trace through phases.
- ❌ Reimplementing existing skills. Check `~/.claude/skills/` first.

## Not in This Pack

- **Updating the orchestrator with the new skill** — handle separately after the skill is built
- **Productizing a skill into a sellable bundle** — see [PACKS.md](../../PACKS.md) for the Pack system
