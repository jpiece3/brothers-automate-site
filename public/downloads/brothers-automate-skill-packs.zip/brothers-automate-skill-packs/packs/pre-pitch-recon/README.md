# Pack: Pre-Pitch Recon

**Mission:** Full reconnaissance before a sales call — SEO posture, competitive landscape, and ICP intel — without the full Pitch Pack overhead.

**Theme:** Research & Intel

## Outcome

You walk away with:
- A client-facing scan report (no jargon)
- Internal prep doc with weak spots and opportunities
- Top 3 organic competitors with traffic/keyword data
- Raw DataForSEO data for any custom analysis

## When to Use This Pack

- You have a small / mid-sized prospect and want fast, defensible intel before the call
- You don't need stakeholder mapping or creative concepts (use [Pitch a New Client](../pitch-new-client/README.md) for that)
- You want repeatable recon for a list of prospects (run this in batch)

## Prerequisites

- Prospect URL
- DataForSEO API access

## The Chain

### Step 1 — `client-scan`
Comprehensive scan — SEO, digital footprint, audit, pitch plan. Outputs both client-facing and internal versions.
- **Output:** Two reports
- **Pass to next:** Internal prep — gives you who the comps are

### Step 2 — `competitor-intel`
Pull competitive data on the top 3 comps surfaced by `client-scan`. Choose the Quick Scan tier for pre-call recon (full tier is for deals where you've won the meeting).
- **Output:** Comparative report
- **Pass to next:** Custom queries (optional)

### Step 3 — `dataforseo`
Direct API access for any custom analysis the previous two skills didn't cover (specific keywords, backlink audits, SERP feature analysis).
- **Output:** Custom CSV / JSON

## Sample Brief

> "Have a discovery call with Acme Co (acme.com) on Friday. Want a fast recon — scan, top 3 competitors, and any specific weak spots I should know about. Don't need the full pitch deck."

## Timeline

- 1-2 days before the call: Run the Pack
- 30 minutes morning of: Re-skim

## Anti-Patterns

- ❌ Using this for a major deal. For deals worth real money, use [Pitch a New Client](../pitch-new-client/README.md) — the extra steps are worth it.
- ❌ Skipping `client-scan` and going straight to `competitor-intel`. The scan tells you who the comps are; without it, you're guessing.

## Not in This Pack

- **Stakeholder / advisor mapping** — see [Pitch a New Client](../pitch-new-client/README.md) for `advisor-intel`
- **Positioning angles for the pitch** — see [Pitch a New Client](../pitch-new-client/README.md)
- **Creative concepts** — see [Pitch a New Client](../pitch-new-client/README.md)
