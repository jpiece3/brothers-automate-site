# Pack: Presenter / UGC Video

**Mission:** UGC-style talking head video for ads or organic — without filming, without hiring a creator.

**Theme:** Visual Production

## Outcome

You walk away with:
- A short-form script optimized for retention
- AI-generated talking head footage delivering the script
- A polished, edited final video ready to post or load into ad platform

## When to Use This Pack

- You need UGC-style ads but don't have a creator pipeline
- You want to test talking-head formats without committing to being on camera
- You're producing volume (many short videos) and live filming doesn't scale

## Prerequisites

- An AI talking head license / setup
- A clear script topic (or willingness to use `short-form-video-scripts` to develop one)
- Remotion familiarity if you want programmatic editing

## The Chain

### Step 1 — `ai-talking-head`
Generate AI talking head / lip-synced avatar footage.
- **Output:** Talking head footage
- **Pass to next:** Script for the video

### Step 2 — `short-form-video-scripts`
Write or polish the script for hook retention and algorithm signals. Keep it tight (30-60 seconds for ads, 60-90 for organic).
- **Output:** Script with shot/timing notes
- **Pass to next:** Footage + script to editing

### Step 3 — `remotion`
Programmatic editing — captions, B-roll cuts, branded intros/outros. Use for batch production.
- **Output:** Final edited video

## Sample Brief

> "Producing 5 UGC-style ads for a new B2B SaaS launch. Each is a 30-second testimonial-style talking head, captions on, hook in the first 2 seconds. Don't have real customers yet — need synthesized."

## Timeline

- Day 1: Script (step 2)
- Day 2: Generate footage (step 1)
- Day 3: Edit (step 3)

## Anti-Patterns

- ❌ Faking real testimonials. Synthesized voices reading "real" customer quotes is misleading at best, illegal at worst depending on jurisdiction. Use for spokesperson / explainer / educational, not testimonial.
- ❌ Skipping `short-form-video-scripts`. AI talking head with a bad script is the same as a real person with a bad script — gets ignored.
- ❌ Final video over 90 seconds for organic, 30 seconds for ads. Retention dies past these thresholds.

## Not in This Pack

- **Concept generation for what to say** — see [Viral Sprint](../viral-sprint/README.md) for the concept layer
- **Product video without a presenter** — see [Product Video](../product-video/README.md)
- **YouTube long-form with talking head** — see [YouTube Channel](../youtube-channel/README.md)
