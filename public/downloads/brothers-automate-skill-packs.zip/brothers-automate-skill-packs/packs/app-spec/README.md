# Pack: App Spec

**Mission:** Spec a new app frontend-first — clickable mockup before any backend work, then a complete iOS spec ready for engineering.

**Theme:** Build & Ship

## Outcome

You walk away with:
- A clickable UI mockup of the core flows
- A complete iOS app spec (screens, flows, data model, integrations)
- A document engineering can build from

## When to Use This Pack

- You're scoping a new iOS app and want to validate the UX before committing engineering
- You're pitching an app idea and need a clickable prototype + spec for stakeholders
- You're handing off to a dev team and need the spec written cleanly

## Prerequisites

- A clear product hypothesis (what problem, for whom)
- Some idea of the core flows (3-5 screens minimum)

## The Chain

### Step 1 — `mockup`
Build the clickable UI mockup at localhost. Frontend-first per CLAUDE.md.
- **Output:** Clickable mockup
- **Pass to next:** Approved mockup + flows

### Step 2 — `ios-app-spec`
Generate the iOS App Spec from the approved mockup.
- **Output:** Complete spec (screens, flows, data model, integrations, edge cases)

## Sample Brief

> "Speccing an iOS app that helps creators batch their newsletter from voice memos. Core flow: record memo → AI transcribes → AI drafts → user edits → ship to Beehiiv. Want a clickable mockup first, then a full iOS spec."

## Timeline

- Week 1: Mockup + iteration (step 1)
- Week 2: Spec (step 2)

## Anti-Patterns

- ❌ Speccing before mocking. The spec will assume flows that don't survive contact with a clickable prototype.
- ❌ Starting with backend / data model. Frontend-first.
- ❌ Speccing for both iOS and Android in one pass. iOS-specific spec; Android needs its own pass.

## Not in This Pack

- **Marketing site for the app** — see [Web Design](../web-design/README.md)
- **Backend architecture** — outside scope; pair with engineering
- **Android spec** — different platform, different patterns
