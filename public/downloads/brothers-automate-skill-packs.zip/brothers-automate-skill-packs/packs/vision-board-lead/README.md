# Pack: Vision Board Lead

**Mission:** Build a lead magnet around an interactive vision board — emotional, sticky, and segments by what the user is reaching for.

**Theme:** Lead Engine

## Outcome

You walk away with:
- A complete vision board lead magnet experience
- Database schema for capturing user inputs and selections
- A high-engagement asset that segments leads by aspiration

## When to Use This Pack

- You sell into a market where aspiration is the buying motivation (coaching, fitness, lifestyle, personal development)
- You want a lead magnet that's *experienced* rather than *consumed*
- Your audience would screenshot and share a vision board (built-in viral signal)

## Prerequisites

- An offer that maps to user aspirations (not utility)
- Supabase account
- Ability to deploy the generated frontend

## The Chain

### Step 1 — `lead-magnet-vision-board`
Orchestrated build of the vision board interactive experience.
- **Output:** Frontend + experience flow
- **Pass to next:** Database schema needed

### Step 2 — `setup-visionboard-db`
Set up the Supabase tables to capture user inputs, selections, and aspirations.
- **Output:** Database live and connected

## Sample Brief

> "I'm a personal brand coach for women in their 30s/40s rebuilding identity post-career-pivot. Build me a vision board lead magnet themed 'Design Your Next Chapter.'"

## Timeline

- Week 1: Build (step 1)
- Week 2: Database + deploy (step 2)
- Week 3+: Drive traffic, capture leads

## Anti-Patterns

- ❌ Using this for a utility-driven audience (B2B SaaS, finance, ops). The vision board format won't resonate.
- ❌ Treating the vision board as the offer. It's the lead magnet — there must be a paid offer downstream.

## Not in This Pack

- **Email sequence after capture** — bolt on `email-sequences` from [Lead Magnet → Welcome](../lead-magnet-welcome/README.md)
- **Quiz-based segmentation** — see [Quiz Funnel](../quiz-funnel/README.md) instead
