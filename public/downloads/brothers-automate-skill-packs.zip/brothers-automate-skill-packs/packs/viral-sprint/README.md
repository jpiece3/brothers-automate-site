# Pack: Viral Sprint

**Mission:** Plan and ship a 3-5 video short-form sprint engineered against the 6 psychological viral principles, not vibes.

**Theme:** Content Engine

## Outcome

You walk away with:
- 3-5 viral concepts scored against the Format Steal / Curiosity / Identity / Authority / Shareability / Story principles
- Full script for each concept (hook → problem → story → payoff)
- Atomized cross-platform versions (LinkedIn, IG, Twitter) of each concept

## When to Use This Pack

- You're trying to crack short-form video for a brand and have been shipping originals that flop
- You have a product launch and need viral content angles, not generic announcement posts
- You want concept work backed by *why* something will travel, not just creative gut

## Prerequisites

- A brand / product / topic you want viral content for
- Optional: a target platform (TikTok / Reels / Shorts) — concepts adapt but skeleton is the same
- A way to actually film / edit the videos (this Pack delivers concepts and scripts, not finished video)

## The Chain

### Step 1 — `viral-content-principles` (CONCEPT mode)
Generate 3-5 viral concepts. Each one explicitly built on Format Steal + curiosity hook + identity layer + shareability angle + Hook→Problem→Story→Payoff outline.
- **Output:** Concept Cards (one per concept) + strategist's pick on which to test first
- **Pass to next:** The picked concept's outline

### Step 2 — `short-form-video-scripts`
Turn the picked concept's outline into a full shootable script with shot-by-shot breakdown, captions, and pacing notes.
- **Output:** Production-ready script
- **Pass to next:** The script for polish

### Step 3 — `humanizer`
Strip AI tells from any spoken / on-screen text. Most short-form scripts read as written-by-AI even if the visual is great.
- **Output:** Natural-sounding script
- **Pass to next:** Final script for atomization

### Step 4 — `content-atomizer`
Once a video is shot and posted, repurpose into LinkedIn write-up, Twitter thread, IG carousel.
- **Output:** Cross-platform variants

## Sample Brief

> "Brand: small-batch hot sauce company. Audience: 25-40 home cooks who want to seem adventurous. Platform: TikTok. We've been making product-shot videos and they get 200 views. Help."

## Timeline

- Day 1: Concepts (step 1) + script for the picked concept (step 2)
- Day 2: Polish + shoot + edit
- Day 3+: Atomize after the video is live (step 4)

## Anti-Patterns

- ❌ Going straight to `short-form-video-scripts` without `viral-content-principles`. Skipping the principle scoring = back to vibes-based concepting.
- ❌ Picking concepts based on "what we want to say" instead of "what's already working in the format." This Pack is about the Format Steal — borrow what works.
- ❌ Atomizing before the video has had 48-72 hours to find an audience. You don't know which concept worked yet.

## Not in This Pack

- **Filming / editing** — Pack delivers concept and script only
- **Diagnosing why an existing video flopped** — use `viral-content-principles` in DIAGNOSE mode standalone, not the full Pack
- **Long-form content repurposing** — see [Pillar Repurpose](../pillar-repurpose/README.md)
