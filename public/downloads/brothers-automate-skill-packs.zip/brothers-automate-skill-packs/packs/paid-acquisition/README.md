# Pack: Paid Acquisition

**Mission:** Spin up a Meta / Google / LinkedIn paid campaign with creative concepts, copy, targeting strategy, and a daily test cadence.

**Theme:** Sales / Conversion Engine

## Outcome

You walk away with:
- A platform-specific ad campaign structure (Meta, Google, LinkedIn)
- 3-5 creative concepts with visual direction
- Headline + body + CTA variations for testing
- A targeting + testing plan for the first 14 days

## When to Use This Pack

- You're starting paid acquisition for a product / service / offer
- You're scaling spend and need fresh creative to fight ad fatigue
- Your existing ads are underperforming and need a fresh batch

## Prerequisites

- An ad account on the target platform (Meta Business, Google Ads, LinkedIn Campaign Manager)
- A landing page (use [Landing Page Conversion](../landing-page-conversion/README.md) if you don't have one)
- A budget — this Pack delivers the creative, not the spend

## The Chain

### Step 1 — `meta-ads` OR `social-ads` OR `paid-ads` (pick the one that matches the platform)
- `meta-ads` — Facebook / Instagram specifically
- `social-ads` — Meta + creative direction integration via `ai-creative-strategist`
- `paid-ads` — Google / Meta / LinkedIn unified, picks the right format per funnel stage

Pick ONE based on the platform and your need. They overlap — don't run all three.
- **Output:** Ad campaign structure + targeting strategy
- **Pass to next:** Campaign structure for daily creative

### Step 2 — `daily-ads`
Daily ad cadence — generate the rotating creative pool to fight ad fatigue.
- **Output:** Daily creative variations
- **Pass to next:** Variations for copy polish

### Step 3 — `marketing-copy-writer`
Polish the headline / body / CTA variations across all the creative.
- **Output:** Polished ad copy ready to load into the platform
- **Pass to next:** Concepts + copy for visual direction

### Step 4 — `ai-creative-strategist`
For the visual direction of each creative concept — ensures the visuals match the audience and the angle.
- **Output:** Visual concept briefs (and previews where useful)

## Sample Brief

> "Launching a $497 AI marketing course. Platform: Meta. Audience: B2B marketing leads at SaaS companies. Budget: $200/day for the first 14 days. Landing page: [URL]. Build me the campaign structure + first batch of creative."

## Timeline

- Day 1: Campaign structure + first creative batch (steps 1-3)
- Day 2: Visual direction + production briefs (step 4)
- Days 3-14: Run, measure, refresh creative on `daily-ads` cadence

## Anti-Patterns

- ❌ Running all three of `meta-ads` / `social-ads` / `paid-ads` together. Pick the one that fits.
- ❌ Skipping `ai-creative-strategist` and writing visuals as briefs alone. Creative direction is what makes ads stop the scroll.
- ❌ Launching without a tested landing page. Ads can't fix a broken page — fix the page first via [Landing Page Conversion](../landing-page-conversion/README.md).

## Not in This Pack

- **Bid management / pacing optimization** — handle in the ad platform itself
- **Pixel / conversion tracking setup** — outside scope
- **Organic social** — see Content Engine packs
