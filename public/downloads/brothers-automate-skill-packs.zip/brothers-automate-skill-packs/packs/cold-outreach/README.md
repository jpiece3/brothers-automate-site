# Pack: Cold Outreach

**Mission:** Build a prospect list and run a cold email sequence that doesn't get flagged as spam or read as AI.

**Theme:** Lead Engine

## Outcome

You walk away with:
- A standardized CSV of prospects (name, company, role, contact)
- An enriched list with verified emails
- A 3-5 touch cold email sequence that reads like a human wrote it
- A campaign-ready setup for your sending tool of choice

## When to Use This Pack

- You're doing B2B outreach and need volume + quality
- You've tried generic cold email tools and they're getting flagged or ignored
- You want the prospect list and the copy built as one workflow

## Prerequisites

- An ICP defined (industry, role, company size, location)
- A sending domain warmed up
- A sending tool (Instantly, Smartlead, Apollo) — this Pack delivers the list + copy, not the send infrastructure

## The Chain

### Step 1 — `prospect-finder`
Find businesses with contact details in the target location/category. Pulls from Google Maps, Apollo-like databases, Yelp, Yellow Pages, Clutch.
- **Output:** Standardized CSV
- **Pass to next:** The CSV (raw) for enrichment

### Step 2 — `apify-lead-generation`
Enrichment pass — adds emails from business websites and other sources. Augments the prospect-finder list.
- **Output:** Enriched CSV with verified contacts
- **Pass to next:** Enriched list + ICP details

### Step 3 — `cold-email-sequence`
Generate the 3-5 touch cold email sequence with subject lines, timing, full copy.
- **Output:** Sequence copy
- **Pass to next:** Sequence for polish

### Step 4 — `humanizer`
Strip AI tells. Cold email is the most aggressively spam-filtered channel — AI patterns get caught.
- **Output:** Natural-sounding sequence ready to load into the sending tool

## Sample Brief

> "ICP: marketing agency owners with 5-50 employees in the US Northeast. We sell a fractional CMO service for $5K/month. Need 200 prospects with verified emails and a 4-touch cold sequence."

## Timeline

- Day 1: List build + enrichment (steps 1-2)
- Day 2-3: Sequence + polish (steps 3-4)
- Day 4+: Load and send

## Anti-Patterns

- ❌ Skipping enrichment. Raw `prospect-finder` lists have ~30-40% bad emails. Always enrich.
- ❌ Skipping `humanizer`. Cold email is the highest-stakes channel for AI detection — domain reputation can be ruined by one bad campaign.
- ❌ Sending without a warmed domain. This Pack delivers the assets but cannot save you from a cold inbox.

## Not in This Pack

- **Sending infrastructure / domain warmup** — handle in your sending tool
- **LinkedIn outreach** — overlaps but `cold-email-sequence` is email-specific
- **Local-business cold outreach** — see [Local Lead](../local-lead/README.md)
