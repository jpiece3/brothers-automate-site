# Pack: Pitch a New Client

**Mission:** Walk into a sales meeting with audit-grade prep — competitive analysis, positioning angles, and creative concepts ready to land the pitch.

**Theme:** Sales / Conversion Engine

## Outcome

You walk away with:
- A full client-side scan (SEO posture, digital footprint, audit findings)
- Competitor analysis showing where the prospect is losing ground
- Pre-built positioning angles for how you'd attack the problem
- Creative concepts to drop in the meeting (visuals where useful)

## When to Use This Pack

- You have a sales meeting or pitch coming up and want to walk in with the work already done
- You're targeting a specific company and want to know everything before the call
- You're pitching consulting / agency / fractional services where prep wins the room

## Prerequisites

- A target prospect (URL, company name)
- A general idea of what you'd offer them
- DataForSEO API for the SEO portions of `client-scan` and `competitor-intel`

## The Chain

### Step 1 — `client-scan`
Comprehensive prospect/client scan — full SEO analysis, company intel briefing, website audit, pitch plan. Outputs both client-facing reports (no jargon) and internal prep docs.
- **Output:** Client report + internal prep
- **Pass to next:** Internal prep — competitor names, weak spots, positioning gaps

### Step 2 — `competitor-intel`
Decompose the prospect's organic competitors. Traffic, keywords, backlinks, content gaps. Choose tier based on the deal size:
- Quick Scan ($500 deals)
- Full Analysis ($1,500 deals)
- Strategic Report ($3,000+ deals)
- **Output:** Styled HTML report + raw JSON
- **Pass to next:** Top 3 competitive gaps

### Step 3 — `advisor-intel`
Orchestrated deep-dive on advisors / decision-makers / stakeholders if the deal needs that level of intel. Skip if the prospect is small.
- **Output:** Stakeholder map + leverage points
- **Pass to next:** Decision-makers + their priorities

### Step 4 — `positioning-angles`
Generate 3-5 positioning options for *how you would solve their problem*. Bring this to the meeting as "here's the angle I'd attack this from."
- **Output:** Positioning angles with headlines
- **Pass to next:** Top angle for creative

### Step 5 — `ai-creative-strategist`
Optional — generate creative concepts (visual direction, campaign idea, naming) the prospect can react to in the meeting. Use when you want to leave with momentum, not a follow-up call.
- **Output:** Creative concepts + previews

## Sample Brief

> "Pitching XYZ Co (URL: xyz.com) next Tuesday. They're a mid-market e-commerce brand. I sell fractional CMO services. Want full prep — scan, competitive analysis, 3-5 positioning angles for how I'd attack their growth problem, and 1-2 creative concepts I can drop in the room."

## Timeline

- 3-5 days before the meeting: Full Pack
- Morning of: Re-skim the internal prep, refresh the angles in your head

## Anti-Patterns

- ❌ Walking into a pitch without the scan. Even 30 minutes of `client-scan` is more prep than 90% of consultants do.
- ❌ Sharing the full internal prep in the meeting. The internal version is for you; the client version is for them.
- ❌ Generating 5 creative concepts and bringing all 5. Pick 1-2 strong ones; multiple options dilute conviction.

## Not in This Pack

- **Proposal writing post-meeting** — bolt on `direct-response-copy` afterwards
- **Follow-up email sequence** — bolt on `email-sequences`
- **Pitch deck design** — use [Web Design](../web-design/README.md) elements if needed
