# Pack: LinkedIn Authority

**Mission:** Build a LinkedIn presence that compounds — voice locked, posts engineered for the algorithm, graphics that stop the scroll.

**Theme:** Content Engine

## Outcome

You walk away with:
- A LinkedIn-specific voice profile
- A 14-day cadence of high-engagement posts (mix of text + carousel + image)
- Scroll-stopping graphics for the carousel posts
- Cross-platform variants (Twitter, newsletter snippet) for each LinkedIn post

## When to Use This Pack

- You're trying to use LinkedIn for thought leadership / inbound and your posts get crickets
- You have a clear topic / beat but no consistent voice or format
- You want a posting cadence built around proven viral frameworks, not generic "post 3× a week"

## Prerequisites

- A LinkedIn account with completed profile
- A clear positioning ("I'm the X person who does Y for Z" — even if loose)
- Time to actually post (this Pack creates posts; it doesn't post them)

## The Chain

### Step 1 — `brand-voice`
Define the LinkedIn voice. LinkedIn is its own dialect — what works on Twitter dies on LinkedIn and vice versa.
- **Output:** Voice profile tuned for LinkedIn
- **Pass to next:** Voice summary

### Step 2 — `linkedin-post-writer`
Draft posts using research-backed viral frameworks (12-word contrarian hook, short paragraph blocks, no emoji bullets, ends with a question).
- **Output:** A batch of LinkedIn posts
- **Pass to next:** The posts that need a graphic

### Step 3 — `scroll-stopping-infographic`
For posts that warrant a graphic (carousel cover, framework diagram, before/after), generate 3 visual directions across 3 different frameworks.
- **Output:** 3 image-gen prompts + design tokens
- **Pass to next:** All 3 directions to feed-stop-score

### Step 4 — `feed-stop-score`
Score the 3 directions on 6 research-backed factors that predict LinkedIn engagement (0-100 each). Pick the winner.
- **Output:** Scored directions + winning pick + revision recommendations
- **Pass to next:** Posts (with chosen graphic spec attached) for polish

### Step 5 — `humanizer`
Strip AI tells. LinkedIn audiences are quick to flag AI-generated posts.
- **Output:** Natural-sounding posts ready to publish

### Step 6 — `content-atomizer`
Cross-post the best LinkedIn posts as Twitter threads, newsletter sections, etc.
- **Output:** Multi-platform variants

## Sample Brief

> "I'm a fractional CMO for B2B SaaS companies. Want to post 3× a week on LinkedIn — mix of frameworks, contrarian takes, and case studies. Voice samples: my last 5 posts on LinkedIn (links). Build me a 14-day cadence."

## Timeline

- Week 1: Voice + first batch of posts (steps 1-2, ~10 posts)
- Week 2: Add graphics to top-3 posts, polish all (steps 3-4)
- Week 3+: Atomize winners, repeat (step 5, ongoing)

## Anti-Patterns

- ❌ Posting LinkedIn copy from Twitter without rewriting. Different audience, different attention pattern.
- ❌ Putting graphics on every post. Graphics are for posts that *need* a visual aid (frameworks, data, before/after) — not for every post.
- ❌ Skipping `humanizer`. AI-tell posts on LinkedIn get sub-3% reach as the algorithm down-ranks them.

## Not in This Pack

- **Viral video / TikTok-style content** — see [Viral Sprint](../viral-sprint/README.md)
- **Newsletter format** — see [Newsletter Launch](../newsletter-launch/README.md)
- **LinkedIn ads** — see [Paid Acquisition](../paid-acquisition/README.md)
