# Pack: Pillar Repurpose

**Mission:** Turn ONE long-form pillar (podcast, newsletter, video, blog) into 10-15 platform-native posts using research-backed rewrite frameworks.

**Theme:** Content Engine

## Outcome

You walk away with:
- A 14-day platform cadence (LinkedIn, Twitter, IG, TikTok) drawn from a single pillar
- Format-specific rewrites — not just chopped-up quotes
- A reusable 1→10 system you can apply to every future pillar

## When to Use This Pack

- You publish long-form regularly (podcast, newsletter, blog) and the social atomization is an afterthought
- You're a creator on multiple platforms and the maintenance is unsustainable
- You want a system that scales (1 pillar → 10 posts → next pillar)

## Prerequisites

- A pillar piece to atomize (transcript, post, or video)
- Active accounts on the platforms you're cascading to
- Brand voice ideally already defined

## The Chain

### Step 1 — `content-repurposing-deep`
Apply the deep rewrite frameworks. Not "post the same thing 5 different ways" — actual platform-native rewrites with hook formulas per platform.
- **Output:** 10-15 posts atomized from the pillar across LinkedIn, Twitter, IG, TikTok
- **Pass to next:** Posts grouped by platform

### Step 2 — `content-atomizer`
Apply additional platform optimization (algorithm signals, CTAs, format tweaks per platform).
- **Output:** Polished cross-platform variants
- **Pass to next:** Twitter-specific variants → step 3, LinkedIn-specific → step 4

### Step 3 — `craft-tweet`
For each Twitter/X post, polish using tweet-specific frameworks.
- **Output:** Optimized tweets, saved to Notion

### Step 4 — `linkedin-post-writer`
For each LinkedIn post, polish using LinkedIn viral frameworks.
- **Output:** Polished LinkedIn posts ready to publish

## Sample Brief

> "I just published a 4,000-word newsletter on 'why most AI startups will die in 18 months.' Atomize it across LinkedIn, Twitter, and IG carousels. I post 3× a week on LinkedIn, daily on Twitter, 2× a week on IG."

## Timeline

- Day 1: Step 1-2 (the bulk of the work)
- Day 2: Polish per-platform (steps 3-4)
- Days 3-16: Publish on cadence

## Anti-Patterns

- ❌ "Atomizing" by copy-pasting the same paragraph to 4 platforms. That's not atomization — that's spray-and-pray.
- ❌ Skipping `craft-tweet` and `linkedin-post-writer`. Platform-specific polish is the difference between a post that hits and one that doesn't.
- ❌ Atomizing every pillar. Some pillars are platform-specific (a YouTube video doesn't always need a Twitter version). Pick selectively.

## Not in This Pack

- **Creating the pillar itself** — see [Newsletter Launch](../newsletter-launch/README.md), [SEO Authority Build](../seo-authority-build/README.md), or [YouTube Channel](../youtube-channel/README.md)
- **Single tweet without a pillar source** — use `craft-tweet` standalone or [Tweet Engine](../tweet-engine/README.md)
