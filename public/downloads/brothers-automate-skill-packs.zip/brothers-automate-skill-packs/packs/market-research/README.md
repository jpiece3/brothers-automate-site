# Pack: Market Research

**Mission:** Map a market — trends, audience, demand, and pricing — before committing to a launch or expansion.

**Theme:** Research & Intel

## Outcome

You walk away with:
- A market snapshot (size, geography, demand patterns, pricing benchmarks)
- Trend analysis showing what's emerging vs declining
- Audience demographics and behavior patterns
- A "go / no-go / pivot" recommendation backed by data

## When to Use This Pack

- You're considering launching into a new market or expanding to a new geography
- You're validating a product idea before building
- You're sizing an opportunity for a strategic decision

## Prerequisites

- A market category (industry / vertical)
- A geography (or list of geographies)
- Apify account for the scraper-based skills

## The Chain

### Step 1 — `apify-market-research`
Analyze market conditions, geographic opportunities, pricing, consumer behavior across Google Maps, Facebook, IG, Booking.com, TripAdvisor.
- **Output:** Market snapshot
- **Pass to next:** Categories + geographies for trend analysis

### Step 2 — `apify-trend-analysis`
Discover and track emerging trends across Google Trends, IG, FB, YouTube, TikTok.
- **Output:** Trend report (rising / steady / declining)
- **Pass to next:** Audience segments for analysis

### Step 3 — `apify-audience-analysis`
Understand audience demographics, preferences, behavior across FB, IG, YouTube, TikTok.
- **Output:** Audience profile

## Sample Brief

> "Considering launching a wellness brand into the Phoenix market. Want a full market scan — local competition, pricing, trends, and what the audience actually engages with on social."

## Timeline

- Week 1: Run the full Pack
- Week 2: Synthesize into go/no-go recommendation

## Anti-Patterns

- ❌ Treating Apify outputs as gospel. They're data — interpretation is on you.
- ❌ Running this on a market you've already committed to. The Pack is for *deciding*, not justifying.
- ❌ Skipping audience analysis. Trends without audience context = noise.

## Not in This Pack

- **Competitor decomposition** — see [Competitor Intelligence](../competitor-intelligence/README.md)
- **Brand reputation tracking** — see [Brand Reputation](../brand-reputation/README.md)
- **Product validation through customer interviews** — outside this Pack's scope; complement with talking to people
