# Pack: Lead Magnet → Welcome

**Mission:** Capture an email and warm the subscriber to a paid offer through a 5-7 email sequence.

**Theme:** Lead Engine

## Outcome

You walk away with:
- 3-5 lead magnet concepts with hooks, formats, and bridges to your paid offer
- A landing page for the chosen lead magnet
- A complete welcome / nurture / conversion email sequence (5-7 emails)
- All polished to read like a human, not an AI

## When to Use This Pack

- You have a paid offer and need a top-of-funnel lead magnet to feed it
- You have an email list but no welcome sequence (or the welcome sequence isn't converting)
- You want the lead magnet → email sequence → paid offer flow built as one coherent system

## Prerequisites

- A paid offer (course, consulting, product, service) you want to drive subs to
- Audience clarity (who's the lead magnet for)
- An ESP (ConvertKit, Beehiiv, etc.)
- Optional: brand voice profile (this Pack will create one if missing)

## The Chain

### Step 1 — `lead-magnet`
Generate 3-5 lead magnet concepts with hooks, formats, and clear bridges to your paid offer.
- **Output:** Lead magnet concepts with strategist's pick
- **Pass to next:** Picked concept + audience pain points

### Step 2 — `direct-response-copy`
Write the landing page for the picked lead magnet.
- **Output:** Conversion-focused landing page
- **Pass to next:** Lead magnet concept + landing page positioning + paid offer details

### Step 3 — `email-sequences`
Build the welcome → nurture → conversion sequence (typically 5-7 emails) that warms the new subscriber to the paid offer.
- **Output:** Complete email sequence with subject lines, timing, full copy
- **Pass to next:** Each email for polish

### Step 4 — `humanizer`
Strip AI tells from landing page + emails. Subscribers spot AI fast.
- **Output:** Natural-sounding copy across the funnel

## Sample Brief

> "I sell a $2K/month fractional CMO service to B2B SaaS founders. Need a lead magnet that attracts that audience and warms them to a discovery call. My voice is contrarian and skeptical of growth-hack tactics."

## Timeline

- Week 1: Lead magnet concept + landing page (steps 1-2)
- Week 2: Email sequence (step 3)
- Week 3: Polish + deploy (step 4)

## Anti-Patterns

- ❌ Picking the lead magnet before knowing the paid offer. The lead magnet must bridge to the offer, not stand alone.
- ❌ Skipping `humanizer` on the email sequence. Welcome sequence emails get the most scrutiny — they decide whether the subscriber stays or unsubs.
- ❌ Building a 14-email sequence when 5 will do. Length kills conversion. Tighter is better.

## Not in This Pack

- **Quiz-based lead capture** — see [Quiz Funnel](../quiz-funnel/README.md)
- **Cold outreach to acquire subscribers** — see [Cold Outreach](../cold-outreach/README.md)
- **Driving paid traffic to the landing page** — see [Paid Acquisition](../paid-acquisition/README.md)
