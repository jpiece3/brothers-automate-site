# Pack: Product Video

**Mission:** Animated product reveals + e-commerce video at scale, without a video production team.

**Theme:** Visual Production

## Outcome

You walk away with:
- Hero product video / reveal animation
- E-commerce-ready video assets (multiple aspect ratios)
- Programmatic editing pipeline (Remotion) for batch production at scale

## When to Use This Pack

- You're launching a physical product and need motion creative for ads + landing pages
- You're scaling an e-comm catalog and need video for hundreds of SKUs
- You want to programmatically generate variations (different colors, configs, audiences)

## Prerequisites

- Product source assets (images, 3D model if you have one)
- A target platform (Meta, TikTok, Amazon listings — drives aspect ratios)
- Remotion familiarity if going the programmatic route

## The Chain

### Step 1 — `ai-product-video`
Specialized for product reveals, animated shots, hero video banners, e-comm video.
- **Output:** Production-ready product videos
- **Pass to next:** Variations needed at scale

### Step 2 — `remotion`
React-based video composition for programmatic editing. Use when you need 100 variations or batch production from data.
- **Output:** Templated video pipeline

## Sample Brief

> "Launching 12 new SKUs in the espresso cup line. Need a 6-second reveal video for each, in 3 aspect ratios (1:1 for IG, 9:16 for Reels, 16:9 for product page). 36 videos total."

## Timeline

- Week 1: Hero video for the lead SKU (step 1)
- Week 2: Remotion template + batch generation (step 2)

## Anti-Patterns

- ❌ Going straight to Remotion without proving the visual direction first. Build the hero in step 1, lock the aesthetic, then templatize.
- ❌ Generating 100 variations without picking a winner. Multiple variations are useful for testing, not for posting all of them.

## Not in This Pack

- **Static product photography** — see [Product Photography](../product-photography/README.md)
- **Talking-head video about the product** — see [Presenter / UGC Video](../presenter-ugc-video/README.md)
- **YouTube long-form** — see [YouTube Channel](../youtube-channel/README.md)
