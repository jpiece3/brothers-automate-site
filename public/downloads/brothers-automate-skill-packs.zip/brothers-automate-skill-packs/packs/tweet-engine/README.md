# Pack: Tweet Engine

**Mission:** Ship tweets at cadence without sounding like an AI wrote them.

**Theme:** Content Engine

## Outcome

You walk away with:
- A batch of tweets drafted from topics or polished from your own raw drafts
- All saved to Notion (your tweet inventory)
- Each one passed through humanizer to remove AI tells

## When to Use This Pack

- You're posting on Twitter/X regularly and need batch-drafting throughput
- You have raw tweet ideas in a notes app and need them polished before posting
- You're building a tweet inventory in Notion that you can pull from on busy days

## Prerequisites

- Notion workspace connected (the `craft-tweet` skill saves directly to Notion)
- A topic / theme / running list of tweet ideas

## The Chain

### Step 1 — `craft-tweet`
Draft new tweets from topics OR polish your existing drafts. Saves directly to Notion.
- **Output:** Tweet drafts in Notion
- **Pass to next:** Each tweet for the polish pass

### Step 2 — `humanizer`
Strip AI tells. Twitter's audience is the most AI-pattern-savvy of any platform — anything that smells like AI gets ratio'd.
- **Output:** Natural-sounding tweets ready to publish

## Sample Brief

> "Polish these 5 raw tweet ideas and save to Notion: [paste list]. My voice is contrarian, plain-spoken, no emojis."

## Timeline

- Same-session for both steps. This is a fast Pack.

## Anti-Patterns

- ❌ Skipping `humanizer`. A polished AI-tell tweet still gets ratio'd.
- ❌ Drafting 50 tweets in one session. Voice fatigue degrades the last 30. Batch in groups of 5-10.

## Not in This Pack

- **Tweets atomized from a long-form pillar** — see [Pillar Repurpose](../pillar-repurpose/README.md)
- **Twitter threads** — use `content-atomizer` for thread-style multi-tweet content
- **Twitter ads** — see [Paid Acquisition](../paid-acquisition/README.md)
