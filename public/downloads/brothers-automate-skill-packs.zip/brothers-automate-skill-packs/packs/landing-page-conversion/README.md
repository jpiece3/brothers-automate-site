# Pack: Landing Page Conversion

**Mission:** Ship a landing page that actually converts — angle locked, copy persuasive, design that doesn't fight the copy.

**Theme:** Sales / Conversion Engine

## Outcome

You walk away with:
- A locked positioning angle for the page
- Conversion-focused copy (headline, subhead, body, CTA)
- A design direction matched to the audience
- A clean, deployable page that reads like a human wrote it

## When to Use This Pack

- You're launching a product / service / offer and need a high-converting landing page
- You have a landing page that's getting traffic but not converting (rebuild)
- You're testing a new angle and want a dedicated page to test it on

## Prerequisites

- A clear offer (what you're selling, to whom, for how much)
- An idea of where traffic will come from (paid ads, SEO, email — informs the page structure)
- Brand voice ideally already defined

## The Chain

### Step 1 — `positioning-angles`
Find the differentiated angle for this page. Not "what we do" — what the *one thing* is that makes someone stop and read.
- **Output:** 3-5 positioning options with headline directions
- **Pass to next:** Winning angle (1-2 sentences)

### Step 2 — `direct-response-copy`
Write the page copy. This skill carries the canonical reference material from Schwartz, Hopkins, Ogilvy, Halbert — use it.
- **Output:** Headline, subhead, body, CTAs, social proof framing
- **Pass to next:** Copy + page intent for design

### Step 3 — `web-designer`
Pick the design direction (one of 6 style families) and apply the landing page framework.
- **Output:** Design brief + style tokens + section-by-section layout
- **Pass to next:** Design direction for component-level production

### Step 4 — `ui`
Generate production-ready UI components in the chosen style (Soft / Sharp / Glass / Glossy).
- **Output:** Deployable UI
- **Pass to next:** Final copy for polish

### Step 5 — `humanizer`
Strip AI tells from the body copy. Headlines and CTAs are usually fine; body copy is where AI tells creep in.
- **Output:** Natural-sounding copy ready to ship

## Sample Brief

> "I'm launching a $497 cohort course on AI for marketing operators. Audience: B2B marketing leads at SaaS companies. Need a long-form landing page. Traffic source will be cold paid ads."

## Timeline

- Day 1: Angle + copy (steps 1-2)
- Day 2: Design + UI (steps 3-4)
- Day 3: Polish + deploy (step 5)

## Anti-Patterns

- ❌ Designing before the copy is locked. Design serves the copy, not the other way around.
- ❌ Skipping `positioning-angles` because "we already know our positioning." Page-level angle is different from brand-level positioning. Re-run for each page.
- ❌ Long-form when short-form fits. If the offer is sub-$50 and the audience already knows you, a long-form page kills conversion.

## Not in This Pack

- **Driving traffic** — see [Paid Acquisition](../paid-acquisition/README.md), [SEO Authority Build](../seo-authority-build/README.md)
- **Email follow-up after opt-in** — see [Lead Magnet → Welcome](../lead-magnet-welcome/README.md)
- **A/B testing infrastructure** — handle in your tool of choice (Vercel, Convertkit, Webflow)
