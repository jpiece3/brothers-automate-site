# Pack: Code Review

**Mission:** Review PRs and explain code with security in mind — without missing what a tired human reviewer would.

**Theme:** Build & Ship

## Outcome

You walk away with:
- A complete PR review with line-level comments
- A security-focused pass identifying vulnerabilities (auth, injection, secrets, OWASP Top 10)
- Diagnosis of the changes' purpose vs. implementation
- Plain-English explanation of unclear code sections

## When to Use This Pack

- You're reviewing a PR (your own or someone else's) and want depth, not just LGTM
- You're auditing changes for security implications before merge
- You're onboarding to unfamiliar code and need it explained

## Prerequisites

- A PR / branch / set of changes to review
- Repository access

## The Chain

### Step 1 — `review`
Standard PR review. Goes through changes file-by-file, flags issues.
- **Output:** Review comments
- **Pass to next:** The review for security pass

### Step 2 — `security-review`
Security-focused review of pending changes on current branch. Looks for OWASP Top 10, secrets, auth flaws, injection.
- **Output:** Security findings
- **Pass to next:** Anything unclear or surprising for diagnosis

### Step 3 — `diagnose` (optional)
When the changes don't make sense or a fix appears wrong, force structured re-diagnosis instead of trusting the surface read.
- **Output:** Root-cause analysis
- **Pass to next:** Anything that needs to be explained for the team

### Step 4 — `code-explainer` (optional)
Plain-English explanation for the most opaque sections — useful for the PR description, code comments, or onboarding docs.
- **Output:** Explanations

## Sample Brief

> "Review this PR — it adds OAuth login. Want a full review including a security pass since it touches auth. Then explain the token refresh logic in plain English for the PR description."

## Timeline

- Small PR: 15-30 minutes
- Large PR with security implications: 1-2 hours

## Anti-Patterns

- ❌ Skipping `security-review` for any PR that touches auth, payments, user data, or external APIs. Even small changes can introduce vulnerabilities.
- ❌ Approving without running `diagnose` when something feels off. "I don't understand it but it works" is a red flag.
- ❌ Using `code-explainer` to write fluff comments. Use it for genuinely opaque code, not for `// increment counter`.

## Not in This Pack

- **Pre-push hygiene before submitting the PR** — see [Pre-Push Hygiene](../pre-push-hygiene/README.md)
- **Architectural review** — outside scope; pair with a senior engineer
