# Pack: Apify Actor Build

**Mission:** Build, actorize, or productize an Apify Actor — from new code, an existing project, or a CLI tool.

**Theme:** Build & Ship

## Outcome

You walk away with:
- A deployed Apify Actor running on the platform
- Output schemas (dataset, key-value-store) properly defined
- An Actor that can be sold on the Apify marketplace OR run as internal infra

## When to Use This Pack

- You have a scraping / automation script and want to run it serverless on Apify
- You want to monetize a tool by selling it on the Apify marketplace
- You're migrating a Python / JavaScript project to the Actor SDK

## Prerequisites

- Apify account
- Code to actorize (or willingness to write it from scratch)
- For TypeScript: Node 20+. For Python: 3.10+

## The Chain

### Step 1 — `apify-actor-development`
Develop / debug / deploy Actors. Use for new Actors or deep modifications to existing ones.
- **Output:** Working Actor on the platform
- **Pass to next:** Existing project to wrap (if applicable)

### Step 2 — `apify-actorization`
Convert existing projects into Actors. Adds SDK init/exit (TS), async context manager (Python), or CLI wrapper for any language.
- **Output:** Actorized project
- **Pass to next:** Schema definition needed

### Step 3 — `apify-generate-output-schema`
Generate `dataset_schema.json`, `output_schema.json`, `key_value_store_schema.json` by analyzing source.
- **Output:** Schemas committed to the Actor

## Sample Brief

> "Have a Python scraper that pulls competitor pricing from a niche marketplace. Want to actorize it so it runs on a schedule and outputs to a dataset I can pull from."

## Timeline

- Day 1: Build / actorize (steps 1-2)
- Day 2: Schemas + deploy (step 3)

## Anti-Patterns

- ❌ Skipping the schema step. An Actor without proper schemas can't be sold or chained cleanly.
- ❌ Building from scratch with `apify-actor-development` when an existing project would work — try `apify-actorization` first.

## Not in This Pack

- **Using Apify Actors for research / data pulls** — see [Universal Scrape](../universal-scrape/README.md) and the other Research Packs
- **Selling the Actor on the marketplace** — outside scope (Apify dashboard handles listing)
