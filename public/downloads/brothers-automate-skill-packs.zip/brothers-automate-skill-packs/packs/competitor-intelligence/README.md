# Pack: Competitor Intelligence

**Mission:** Decompose what a competitor is doing across SEO, paid, social, and content — and find the gaps you can exploit.

**Theme:** Research & Intel

## Outcome

You walk away with:
- Their organic / SEO posture (traffic, keywords, backlinks, content gaps)
- Their paid + social strategy (ads, formats, frequency)
- Their content engagement patterns (what's working, what's flopping)
- A prioritized list of gaps and counter-positions

## When to Use This Pack

- You're entering a market and need to know who's already there
- A specific competitor is winning and you need to figure out why
- You're preparing a strategic positioning move

## Prerequisites

- Competitor URLs / handles across the platforms you care about
- DataForSEO API for the SEO portion
- Apify account for the social/content portion

## The Chain

### Step 1 — `competitor-intel`
Data-driven competitive analysis using DataForSEO. Three tiers (Quick / Full / Strategic). Pick based on stakes.
- **Output:** Styled HTML report + raw JSON — traffic, keywords, backlinks, content gaps, tech stack
- **Pass to next:** Their handles + content focus

### Step 2 — `apify-competitor-intelligence`
Analyze competitor strategies, content, pricing, ads, market positioning across Google Maps, Booking.com, FB, IG, YouTube, TikTok.
- **Output:** Multi-platform competitor breakdown
- **Pass to next:** Their top-performing content for engagement analysis

### Step 3 — `apify-content-analytics`
Track engagement metrics on their content across IG, FB, YouTube, TikTok.
- **Output:** Engagement patterns + outliers (what's truly working vs vanity metrics)

## Sample Brief

> "Want to decompose Brand X (their main competitor in the AI tools space). Need full SEO breakdown, social strategy, ad approach, and content performance data."

## Timeline

- Week 1: Run the full Pack
- Week 2: Synthesize gaps + counter-positions

## Anti-Patterns

- ❌ Copying what the competitor is doing. The Pack is for finding *gaps*, not for cloning.
- ❌ Reporting on engagement totals without normalizing for follower count. A 10K-like post on a 1M account is a flop; on a 50K account it's a hit.
- ❌ Decomposing 5 competitors at once. Pick 1-2; depth beats breadth.

## Not in This Pack

- **Pricing intelligence** — see [Universal Scrape](../universal-scrape/README.md) for `apify-ecommerce` if it's a product
- **Influencer / partnership intel** — see [Brand Reputation](../brand-reputation/README.md) for `apify-influencer-discovery`
- **Pre-pitch competitor scan for a sales call** — see [Pre-Pitch Recon](../pre-pitch-recon/README.md)
