# Skill Packs

Curated bundles of skills mapped to business outcomes. A skill can belong to multiple Packs because horizontal utilities (`brand-voice`, `humanizer`, `dataforseo`) span many outcomes.

**How to use:**
- Each Pack is a *chain* — skill A → skill B → skill C — designed to deliver a specific business outcome (launch a newsletter, build a viral sprint, win a pitch).
- Pack folders at `~/.claude/packs/<pack-slug>/README.md` contain the full manifest: mission, skill chain with handoff context, sample brief, timeline, prerequisites.
- The `orchestrator` skill knows about Packs — say "I want to launch a newsletter" and it routes you to the Newsletter Launch Pack chain rather than a single skill.
- A customer-facing showcase lives at `~/.claude/packs/index.html` (Operator's Catalog framing).

**One critical rule (carried forward from `orchestrator`):** more context is not always better. Pass essentials between chain steps, not full outputs. See the Context Paradox section in `~/.claude/skills/orchestrator/SKILL.md` before chaining.

---

## Theme 1 — Content Engine

| Pack | Outcome | Skill Chain |
|------|---------|-------------|
| [Newsletter Launch](packs/newsletter-launch/README.md) | Ship a newsletter readers actually open | `brand-voice` → `positioning-angles` → `newsletter` → `email-newsletter-writer` → `humanizer` → `anti-slop` → `content-atomizer` |
| [Operator Newsletter](packs/operator-newsletter/README.md) | Run the Operator's AI Playbook pipeline end-to-end | `operator-playbook-drafter` → `newsletter-autopilot` → `operator-social-atomizer` |
| [Viral Sprint](packs/viral-sprint/README.md) | Plan a short-form video sprint engineered for scroll-stop | `viral-content-principles` → `short-form-video-scripts` → `humanizer` → `content-atomizer` |
| [LinkedIn Authority](packs/linkedin-authority/README.md) | Build a LinkedIn presence that compounds | `brand-voice` → `linkedin-post-writer` → `scroll-stopping-infographic` → `feed-stop-score` → `humanizer` → `content-atomizer` |
| [SEO Authority Build](packs/seo-authority-build/README.md) | Rank for defensible keywords in 2026 SERPs | `keyword-research-deep` → `seo-blog-writer` → `seo-content` → `humanizer` → `content-atomizer` → `seo-blog-autopilot` |
| [YouTube Channel](packs/youtube-channel/README.md) | Launch and package a YouTube channel for CTR | `keyword-research` → `short-form-video-scripts` → `youtube-seo-packaging` → `ai-talking-head` → `remotion` |
| [Pillar Repurpose](packs/pillar-repurpose/README.md) | Turn one long-form pillar into 10-15 platform-native posts | `content-repurposing-deep` → `content-atomizer` → `craft-tweet` → `linkedin-post-writer` |
| [Tweet Engine](packs/tweet-engine/README.md) | Ship tweets at cadence without sounding like an AI | `craft-tweet` → `humanizer` |

## Theme 2 — Lead Engine

| Pack | Outcome | Skill Chain |
|------|---------|-------------|
| [Quiz Funnel](packs/quiz-funnel/README.md) | Build a quiz-based lead generation system end-to-end | `lead-magnet-quiz` → `setup-quiz-db` → `funnel-optimizer` |
| [Lead Magnet → Welcome](packs/lead-magnet-welcome/README.md) | Capture an email and warm the subscriber to a paid offer | `lead-magnet` → `direct-response-copy` → `email-sequences` → `humanizer` |
| [Vision Board Lead](packs/vision-board-lead/README.md) | Lead magnet built on a vision board interactive | `lead-magnet-vision-board` → `setup-visionboard-db` |
| [Cold Outreach](packs/cold-outreach/README.md) | Build a list and run a cold email sequence that doesn't get flagged | `prospect-finder` → `apify-lead-generation` → `cold-email-sequence` → `humanizer` |
| [Local Lead](packs/local-lead/README.md) | Rank in the Google local 3-pack and convert it into outreach | `local-seo` → `prospect-finder` → `cold-email-sequence` |

## Theme 3 — Sales / Conversion Engine

| Pack | Outcome | Skill Chain |
|------|---------|-------------|
| [Landing Page Conversion](packs/landing-page-conversion/README.md) | Ship a landing page that actually converts | `positioning-angles` → `direct-response-copy` → `web-designer` → `ui` → `humanizer` |
| [Paid Acquisition](packs/paid-acquisition/README.md) | Spin up a Meta/Google paid campaign with creative + copy | `meta-ads` → `social-ads` → `paid-ads` → `daily-ads` → `marketing-copy-writer` → `ai-creative-strategist` |
| [Pitch a New Client](packs/pitch-new-client/README.md) | Walk into a sales meeting with audit-grade prep | `client-scan` → `competitor-intel` → `advisor-intel` → `positioning-angles` → `ai-creative-strategist` |

## Theme 4 — Research & Intel

| Pack | Outcome | Skill Chain |
|------|---------|-------------|
| [Pre-Pitch Recon](packs/pre-pitch-recon/README.md) | Full reconnaissance before a sales call (SEO, comp, ICP) | `client-scan` → `competitor-intel` → `dataforseo` |
| [Market Research](packs/market-research/README.md) | Map a market: trends, audience, pricing, demand | `apify-market-research` → `apify-trend-analysis` → `apify-audience-analysis` |
| [Competitor Intelligence](packs/competitor-intelligence/README.md) | Decompose what a competitor is doing across SEO and social | `competitor-intel` → `apify-competitor-intelligence` → `apify-content-analytics` |
| [Brand Reputation](packs/brand-reputation/README.md) | Monitor reviews, mentions, and influencer chatter for a brand | `apify-brand-reputation-monitoring` → `apify-influencer-discovery` → `apify-audience-analysis` |
| [Universal Scrape](packs/universal-scrape/README.md) | Pull data from any platform using Apify + Firecrawl | `apify-ultimate-scraper` → `apify-ecommerce` → Firecrawl MCP |

## Theme 5 — Visual Production

| Pack | Outcome | Skill Chain |
|------|---------|-------------|
| [Product Photography](packs/product-photography/README.md) | Generate hero / lifestyle product shots without a studio | `ai-product-photo` → `ai-image-generation` |
| [Product Video](packs/product-video/README.md) | Animated product reveals + e-comm video at scale | `ai-product-video` → `remotion` |
| [Social Graphics](packs/social-graphics/README.md) | Scroll-stopping LinkedIn / Twitter / IG graphics on demand | `scroll-stopping-infographic` → `feed-stop-score` → `ai-social-graphics` → `ai-image-generation` |
| [Presenter / UGC Video](packs/presenter-ugc-video/README.md) | UGC-style talking head video for ads or organic | `ai-talking-head` → `short-form-video-scripts` → `remotion` |
| [Web Design](packs/web-design/README.md) | Frontend-first scoping and design for a marketing site | `mockup` → `ui` → `web-designer` |
| [Diagrams](packs/diagrams/README.md) | Build technical / strategy diagrams fast | `excalidraw` |

## Theme 6 — Build & Ship

| Pack | Outcome | Skill Chain |
|------|---------|-------------|
| [Apify Actor Build](packs/apify-actor-build/README.md) | Build, actorize, or productize an Apify Actor | `apify-actor-development` → `apify-actorization` → `apify-generate-output-schema` |
| [App Spec](packs/app-spec/README.md) | Spec an app frontend-first before any backend work | `mockup` → `ios-app-spec` |
| [Pre-Push Hygiene](packs/pre-push-hygiene/README.md) | Don't push broken code; run typecheck/build/lint and ship clean | `precheck` → `ship` → `push-to-github` → `safedev` → `simplify` |
| [Code Review](packs/code-review/README.md) | Review PRs and explain code with security in mind | `review` → `security-review` → `diagnose` → `code-explainer` |
| [Workflow Automation](packs/workflow-automation/README.md) | Map or design a Gumloop automation | `gumloop-workflow-designer` |

## Theme 7 — Operator Stack

| Pack | Outcome | Skill Chain |
|------|---------|-------------|
| [Strategist](packs/strategist/README.md) | Get unstuck, find the angle, route to the right Pack | `orchestrator` → `wed` → `ai-creative-strategist` → `positioning-angles` → `diagnose` |
| [Skill Building](packs/skill-building/README.md) | Productize a workflow into a research-backed skill | `skill-creator` |
| [Voice & Anti-Slop](packs/voice-anti-slop/README.md) | Lock down a brand voice, kill AI tells, ship clean copy | `brand-voice` → `humanizer` → `anti-slop` → `auto-improve` |
| [Mac/Workspace Hygiene](packs/mac-workspace-hygiene/README.md) | Reclaim disk, clean projects, reset the workspace | `clean-mac` → `init` |

---

## Horizontal Utilities

These skills don't anchor a Pack — they're dependencies that show up across many chains. When you see them in a Pack manifest, treat them as either a one-time setup (`brand-voice`, `dataforseo` API setup) or a polish pass (`humanizer`, `anti-slop`) at the end of a chain.

| Skill | Used in |
|-------|---------|
| `brand-voice` | Newsletter Launch, LinkedIn Authority, Voice & Anti-Slop, and as a foundation for any content/copy Pack |
| `humanizer` | Almost every content/copy Pack as a final polish step |
| `anti-slop` | Newsletter Launch, Voice & Anti-Slop, any pack producing long-form text |
| `dataforseo` | Pre-Pitch Recon, SEO Authority Build, Competitor Intelligence — anywhere SEO data is needed |
| `auto-improve` | Voice & Anti-Slop, but useful as a diagnostic on any underperforming asset |
| `diagnose` | Strategist Pack, Code Review Pack — when the first fix didn't work |

---

## Excluded from Packs

Documented for completeness so you don't keep wondering "where's that skill in the catalog?"

- **Hatfieldbot project commands** (`it-prep`, `log-interaction`, `decision`, `risk`, `question`, `update-status`) — project-scoped at `/Users/jamespinder/hatfieldbot/.claude/commands/`. Not global, not productizable.
- **Telegram skills** (`telegram:configure`, `telegram:access`) — single-user infrastructure utility.
- **Settings utilities** (`update-config`, `keybindings-help`, `fewer-permission-prompts`) — Claude Code admin, not business outcomes.
- **Loop / Schedule / Push Notification** (`loop`, `schedule`) — execution primitives. Used inside Packs but don't anchor a Pack.
- **Claude API** (`claude-api`) — engineering utility for building things with the Anthropic SDK. Useful, but not a marketing/business Pack.

---

## Maintenance

When a new skill is added to `~/.claude/skills/`:
1. Decide if it anchors a new Pack, fits an existing Pack, or is a horizontal utility.
2. Update the relevant table here AND the matching Pack's `README.md`.
3. If it's a horizontal utility, add it to the Utilities table.
4. Re-run the coverage audit: `ls ~/.claude/skills/ | grep -vE '^_|.zip$|^orchestrator$|^viral-content-principles$' | sort` and cross-check against this file.
